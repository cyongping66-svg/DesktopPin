# -*- coding: utf-8 -*-
"""AI 服务：OpenAI 兼容接口（DeepSeek/通义/Kimi/OpenAI 等），后台线程调用"""
import json
import urllib.request

from PySide6.QtCore import QThread, Signal

import config


class AiWorker(QThread):
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, prompt: str, task: str = "总结", parent=None):
        super().__init__(parent)
        self.prompt = prompt
        self.task = task

    def run(self):
        try:
            ai = config.load()["ai"]
            base = ai.get("base_url", "").rstrip("/")
            key = ai.get("api_key", "")
            model = ai.get("model", "")
            if not base or not key or not model:
                self.failed.emit("请先在设置岛填写 AI 接口地址、API Key 和模型")
                return

            url = base + "/chat/completions"
            payload = {
                "model": model,
                "temperature": 0.3,
                "messages": [
                    {"role": "system",
                     "content": "你是备忘录整理助手。用户会给出多条便签内容，"
                                "请用简体中文输出：1) 一段整体摘要；"
                                "2) 按主题分组的要点整理（保留关键数据与日期）；"
                                "3) 如有待办事项，单独列出清单。格式清晰，不要编造内容。"},
                    {"role": "user", "content": self.prompt},
                ],
            }
            req = urllib.request.Request(
                url, data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {key}",
                })
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            content = data["choices"][0]["message"]["content"].strip()
            if content:
                self.done.emit(content)
            else:
                self.failed.emit("AI 返回内容为空，请检查模型配置")
        except urllib.error.HTTPError as e:
            self.failed.emit(f"接口返回错误 {e.code}：请检查 API Key / 模型名 / 接口地址")
        except Exception as e:  # noqa: BLE001
            self.failed.emit(f"请求失败：{e}")


def collect_memo_texts() -> str:
    """汇总全部便签纯文本（含未保存内容）"""
    from PySide6.QtGui import QTextDocument
    import memo
    parts = []
    for m in memo.ALL_MEMOS:
        doc = QTextDocument()
        doc.setHtml(m.editor.toHtml())
        text = doc.toPlainText().strip()
        if text:
            parts.append(f"【便签 {m.memo_id}】\n{text}")
    return "\n\n".join(parts) if parts else "（便签为空）"
