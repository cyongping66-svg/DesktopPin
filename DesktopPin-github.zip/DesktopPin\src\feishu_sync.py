# -*- coding: utf-8 -*-
"""把一条便签写入指定的飞书新版文档。

点「保存」时调用：本地 backup 成功后，用应用身份覆盖那篇文档的正文。
凭证和文档地址在 settings.json 的 feishu 节，只存在本机。
"""
import json
import mimetypes
import os
import re
import time
import urllib.error
from datetime import datetime
import urllib.parse
import urllib.request
import uuid

from PySide6.QtCore import QThread, Signal

import config

URL_RE = re.compile(
    r"(https?://[^\s<>\"）)】]+|www\.[^\s<>\"）)】]+\.[^\s<>\"）)】]+)")

_API = "https://open.feishu.cn"
_token_cache = {"key": "", "value": "", "exp": 0.0}
_DATE_RE = re.compile(r"星期[一二三四五六日]\s+(\d{4}-\d{2}-\d{2})")


def clear_token():
    """改了 App ID 或 Secret 后必须丢掉旧凭证，否则会拿过期身份去连新配置。"""
    _token_cache["key"] = ""
    _token_cache["value"] = ""
    _token_cache["exp"] = 0.0


def stamp_line(when=None):
    when = when or datetime.now()
    week = "一二三四五六日"[when.weekday()]
    return f"星期{week} {when.strftime('%Y-%m-%d %H:%M:%S')}"


class FeishuError(Exception):
    pass


def _request(method, url, token=None, body=None, raw=None, content_type=None, timeout=60):
    headers = {}
    data = raw
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"
    elif content_type:
        headers["Content-Type"] = content_type
    if token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raw_body = e.read().decode("utf-8", "replace")
        try:
            payload = json.loads(raw_body)
        except Exception:
            raise FeishuError(f"飞书接口 HTTP {e.code}") from e
    except Exception as e:
        raise FeishuError(f"连接飞书失败：{e}") from e
    if payload.get("code") != 0:
        msg = (payload.get("msg") or "未知错误").replace("\n", " ")
        raise FeishuError(f"飞书返回 {payload.get('code')}：{msg[:220]}")
    return payload


def _tenant_token(app_id, app_secret):
    now = time.time()
    key = app_id + "\n" + app_secret
    if (_token_cache["key"] == key and _token_cache["value"]
            and now < _token_cache["exp"] - 120):
        return _token_cache["value"]
    payload = _request(
        "POST", _API + "/open-apis/auth/v3/tenant_access_token/internal",
        body={"app_id": app_id, "app_secret": app_secret})
    token = payload.get("tenant_access_token") or ""
    if not token:
        raise FeishuError("无法获取飞书访问凭证，请检查 App ID 和 App Secret")
    _token_cache["key"] = key
    _token_cache["value"] = token
    _token_cache["exp"] = now + int(payload.get("expire") or 7200)
    return token


def _wiki_token(url):
    m = re.search(r"/wiki/([A-Za-z0-9]+)", url or "")
    return m.group(1) if m else ""


def _docx_token(url):
    m = re.search(r"/docx/([A-Za-z0-9]+)", url or "")
    return m.group(1) if m else ""


def _document_id(cfg, token):
    url = (cfg.get("doc_url") or "").strip()
    cached = (cfg.get("document_id") or "").strip()
    if cached and cfg.get("doc_url_resolved") == url:
        return cached
    wiki = _wiki_token(url)
    if wiki:
        data = _request(
            "GET",
            _API + "/open-apis/wiki/v2/spaces/get_node?token=" + urllib.parse.quote(wiki),
            token=token).get("data") or {}
        node = data.get("node") or {}
        if node.get("obj_type") != "docx":
            raise FeishuError("这篇飞书链接不是新版文档，无法写入")
        doc_id = node.get("obj_token") or ""
    else:
        doc_id = _docx_token(url) or cached
    if not doc_id:
        raise FeishuError("文档链接无法识别，请粘贴飞书新版文档或知识库链接")
    if doc_id != cached or cfg.get("doc_url_resolved") != url:
        fresh = config.load()
        fresh.setdefault("feishu", {})
        fresh["feishu"]["document_id"] = doc_id
        fresh["feishu"]["doc_url_resolved"] = url
        try:
            config.save(fresh)
        except OSError:
            pass
    return doc_id


def _text_elements(line):
    """一行文字拆成普通文本和可点击链接。"""
    elems = []
    last = 0
    for m in URL_RE.finditer(line):
        if m.start() > last:
            elems.append({"text_run": {"content": line[last:m.start()]}})
        url = m.group(0)
        href = url if url.lower().startswith("http") else "https://" + url
        elems.append({
            "text_run": {
                "content": url,
                "text_element_style": {
                    "link": {"url": urllib.parse.quote(href, safe="")},
                },
            }
        })
        last = m.end()
    tail = line[last:]
    if tail:
        elems.append({"text_run": {"content": tail}})
    if not elems:
        elems.append({"text_run": {"content": " "}})
    # 单段过长时切开，避免飞书拒收
    out = []
    for el in elems:
        content = el["text_run"]["content"]
        style = el["text_run"].get("text_element_style")
        while len(content) > 4000:
            piece = {"text_run": {"content": content[:4000]}}
            if style:
                piece["text_run"]["text_element_style"] = style
            out.append(piece)
            content = content[4000:]
        piece = {"text_run": {"content": content}}
        if style:
            piece["text_run"]["text_element_style"] = style
        out.append(piece)
    return out


def _paragraph(line, heading=False):
    elements = _text_elements(line.strip() or " ")
    if heading:
        return {"block_type": 3, "heading1": {"elements": elements, "style": {}}}
    return {"block_type": 2, "text": {"elements": elements, "style": {}}}


def _local_image(src):
    s = (src or "").strip()
    if s.startswith("file:///"):
        s = s[8:]
    s = urllib.parse.unquote(s)
    if len(s) >= 3 and s[0] == "/" and s[2] == ":":
        s = s[1:]
    return s.replace("/", os.sep)


def _blocks_from_segments(segments):
    """segments: {type:text|image|break, text?, path?}"""
    blocks = []
    images = []
    buf = []

    def flush_text():
        text = "".join(buf).replace("\r\n", "\n").replace("\r", "\n").strip("\n")
        buf.clear()
        if not text.strip():
            return
        for line in text.split("\n"):
            if not line.strip():
                continue
            blocks.append(_paragraph(line, heading=False))

    for seg in segments or []:
        kind = seg.get("type")
        if kind == "image":
            flush_text()
            path = _local_image(seg.get("path") or "")
            if path and os.path.isfile(path):
                images.append(path)
            else:
                blocks.append(_paragraph("（有一张图片，本地文件已找不到）"))
        elif kind == "break":
            buf.append("\n")
        else:
            buf.append(seg.get("text") or "")
    flush_text()
    if not blocks and not images:
        blocks.append(_paragraph("（这条便签是空的）"))
    return blocks, images


def _gap():
    """不同日期之间空两行。空格段落会被飞书折掉，用一个换行段落才留得住。"""
    return {"block_type": 2, "text": {
        "elements": [{"text_run": {"content": "\n"}}],
        "style": {},
    }}


def _last_saved_date(content):
    found = _DATE_RE.findall(content or "")
    return found[-1] if found else ""


def _list_children(token, doc_id):
    items = []
    page = ""
    while True:
        q = (f"/open-apis/docx/v1/documents/{doc_id}/blocks/{doc_id}/children"
             "?document_revision_id=-1&page_size=500")
        if page:
            q += "&page_token=" + urllib.parse.quote(page)
        data = _request("GET", _API + q, token=token).get("data") or {}
        items.extend(data.get("items") or [])
        if not data.get("has_more"):
            return items
        page = data.get("page_token") or ""
        if not page:
            return items


def _create_children(token, doc_id, blocks, index=0):
    url = (_API + f"/open-apis/docx/v1/documents/{doc_id}/blocks/{doc_id}/children"
           "?document_revision_id=-1")
    made = []
    for offset in range(0, len(blocks), 50):
        chunk = blocks[offset:offset + 50]
        data = _request("POST", url, token=token, body={
            "index": index + offset,
            "children": chunk,
        }).get("data") or {}
        made.extend(data.get("children") or [])
    return made


def _upload_image(token, doc_id, block_id, path):
    filename = os.path.basename(path) or "image.png"
    with open(path, "rb") as fh:
        content = fh.read()
    if not content:
        raise FeishuError("图片是空文件")
    if len(content) > 20 * 1024 * 1024:
        raise FeishuError("图片超过 20MB，飞书接口不接受")
    mime = mimetypes.guess_type(filename)[0] or "image/png"
    boundary = "----DesktopPin" + uuid.uuid4().hex
    fields = {
        "file_name": filename,
        "parent_type": "docx_image",
        "parent_node": block_id,
        "size": str(len(content)),
        "extra": json.dumps({"drive_route_token": doc_id}, ensure_ascii=False),
    }
    body = bytearray()
    for key, value in fields.items():
        body += f"--{boundary}\r\n".encode()
        body += f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode()
        body += str(value).encode("utf-8") + b"\r\n"
    body += f"--{boundary}\r\n".encode()
    body += (f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
             f"Content-Type: {mime}\r\n\r\n").encode()
    body += content + b"\r\n"
    body += f"--{boundary}--\r\n".encode()
    payload = _request(
        "POST", _API + "/open-apis/drive/v1/medias/upload_all",
        token=token, raw=bytes(body),
        content_type="multipart/form-data; boundary=" + boundary,
        timeout=120)
    file_token = (payload.get("data") or {}).get("file_token") or ""
    if not file_token:
        raise FeishuError("飞书没有返回图片标识")
    # 上传成功不会自动贴进图片块，还要再绑一次
    _request(
        "PATCH",
        _API + f"/open-apis/docx/v1/documents/{doc_id}/blocks/{block_id}"
        "?document_revision_id=-1",
        token=token,
        body={"replace_image": {"token": file_token}})


def _attach_images(token, doc_id, index, paths):
    """逐张上传。没有上传权限时删掉空图片块，改留一句说明，不让整次保存失败。"""
    failed = None
    done = 0
    for path in paths:
        made = _create_children(
            token, doc_id, [{"block_type": 27, "image": {}}], index=index)
        block_id = (made[0].get("block_id") if made else "") or ""
        try:
            _upload_image(token, doc_id, block_id, path)
            done += 1
            index += 1
        except FeishuError as e:
            if block_id:
                try:
                    _request(
                        "DELETE",
                        _API + f"/open-apis/docx/v1/documents/{doc_id}/blocks/{doc_id}/children/batch_delete",
                        token=token,
                        body={"start_index": index, "end_index": index + 1})
                except FeishuError:
                    pass
            failed = str(e)
            break
    left = len(paths) - done
    if not failed:
        return ""
    note = f"（另有 {left} 张图片仍在本机便签里）"
    _create_children(token, doc_id, [_paragraph(note)], index=index)
    if "99991672" in failed or "document.media:upload" in failed:
        return "文字已同步。图片还要在飞书应用里开通「上传图片和附件到云文档」"
    return f"文字已同步。有图片没传上去：{failed[:120]}"


def sync_segments(segments):
    """在飞书文档末尾追加这条便签。返回 (文档链接, 警告或空字符串)。"""
    cfg = (config.load().get("feishu") or {})
    app_id = (cfg.get("app_id") or "").strip()
    app_secret = (cfg.get("app_secret") or "").strip()
    doc_url = (cfg.get("doc_url") or "").strip()
    if not app_id or not app_secret or not doc_url:
        raise FeishuError("请先在设置岛填写飞书 App ID、App Secret 和文档链接")
    token = _tenant_token(app_id, app_secret)
    doc_id = _document_id(cfg, token)
    blocks, images = _blocks_from_segments(segments)
    stamp = stamp_line()
    today = stamp.split()[1]
    raw = _request(
        "GET", _API + f"/open-apis/docx/v1/documents/{doc_id}/raw_content",
        token=token)
    existing = ((raw.get("data") or {}).get("content") or "")
    last_day = _last_saved_date(existing)
    prefix = []
    # 已有内容、且上一条不是今天：先空两行。同一天则紧接在上一条后面。
    if existing.strip() and last_day != today:
        prefix = [_gap()]
    entry = prefix + [_paragraph(stamp, heading=False)] + blocks
    index = len(_list_children(token, doc_id))
    _create_children(token, doc_id, entry, index=index)
    warning = ""
    if images:
        warning = _attach_images(token, doc_id, index + len(entry), images)

    raw = _request(
        "GET", _API + f"/open-apis/docx/v1/documents/{doc_id}/raw_content",
        token=token)
    content = ((raw.get("data") or {}).get("content") or "")
    if stamp not in content:
        raise FeishuError("飞书写入后回读不到这条记录，请确认应用对该文档是可编辑")
    return doc_url, warning


def test_link():
    """用当前配置重新解析文档，确认改完仍能连上。返回文档标题。"""
    clear_token()
    cfg = dict(config.load().get("feishu") or {})
    app_id = (cfg.get("app_id") or "").strip()
    app_secret = (cfg.get("app_secret") or "").strip()
    if not app_id or not app_secret or not (cfg.get("doc_url") or "").strip():
        raise FeishuError("请先填写 App ID、App Secret 和文档链接")
    cfg["document_id"] = ""
    cfg["doc_url_resolved"] = ""
    token = _tenant_token(app_id, app_secret)
    doc_id = _document_id(cfg, token)
    info = _request(
        "GET", _API + f"/open-apis/docx/v1/documents/{doc_id}",
        token=token)
    title = ((info.get("data") or {}).get("document") or {}).get("title") or ""
    return title or "（无标题）"


class FeishuProbeWorker(QThread):
    done = Signal(str)
    failed = Signal(str)

    def run(self):
        try:
            self.done.emit(test_link())
        except Exception as e:  # noqa: BLE001
            self.failed.emit(str(e))


class FeishuSyncWorker(QThread):
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, segments, parent=None):
        super().__init__(parent)
        self.segments = segments

    def run(self):
        try:
            url, warning = sync_segments(self.segments)
            self.done.emit(warning or url)
        except Exception as e:  # noqa: BLE001
            self.failed.emit(str(e))
