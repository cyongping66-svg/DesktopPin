# -*- coding: utf-8 -*-
"""单屏截图选区：热键触发 → 只覆盖鼠标所在屏幕 → 拖框/8向手柄调整 → 确认生成置顶 Pin 图"""
import numpy as np
import mss

from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QPixmap, QPainter, QColor, QPen, QImage, QCursor, QFont
from PySide6.QtWidgets import QWidget, QApplication

ACCENT = "#007AFF"
MIN_SEL = 12  # 选区最小尺寸


def grab_screen(screen) -> QPixmap:
    """抓取指定 QScreen（物理像素）"""
    g = screen.geometry()
    dpr = screen.devicePixelRatio()
    rect = {"left": round(g.x() * dpr), "top": round(g.y() * dpr),
            "width": round(g.width() * dpr), "height": round(g.height() * dpr)}
    with mss.mss() as sct:
        shot = sct.grab(rect)
    arr = np.frombuffer(shot.rgb, dtype=np.uint8).reshape(shot.height, shot.width, 3)
    img = QImage(arr.data, shot.width, shot.height, QImage.Format_RGB888).copy()
    return QPixmap.fromImage(img)


class CaptureOverlay(QWidget):
    """覆盖鼠标所在屏的选区层：拖框 → 手柄调整 → Enter/双击/按钮确认"""

    def __init__(self, on_done, parent=None):
        super().__init__(parent)
        self.on_done = on_done
        self.mode = "idle"          # idle / select / adjust
        self.sel = QRect()          # 选区（widget 坐标）
        self._origin = None         # 拖框起点
        self._start = None          # 调整起点
        self._orig = QRect()        # 调整前选区
        self._action = None         # move / nw / n / ne / e / se / s / sw / w

        self.screen_geo = None
        self.full_pix = None

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint |
                            Qt.Tool | Qt.SubWindow)
        self.setCursor(Qt.CrossCursor)

        self._init_screen()
        self.show()
        self.activateWindow()
        self.raise_()

    def _init_screen(self):
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        self.screen_geo = screen.geometry()
        self.full_pix = grab_screen(screen)
        self.setGeometry(self.screen_geo)
        self.setCursor(Qt.CrossCursor)

    # ---------- 命中检测 ----------
    def _handles(self):
        """8 个手柄位置（widget 坐标）"""
        r = self.sel.normalized()
        cx, cy = r.center().x(), r.center().y()
        return {
            "nw": (r.left(), r.top()), "n": (cx, r.top()),
            "ne": (r.right(), r.top()), "e": (r.right(), cy),
            "se": (r.right(), r.bottom()), "s": (cx, r.bottom()),
            "sw": (r.left(), r.bottom()), "w": (r.left(), cy),
        }

    def _hit_test(self, p):
        if self.sel.isNull() or not self.sel.isValid():
            return None
        for name, (hx, hy) in self._handles().items():
            if abs(p.x() - hx) <= 9 and abs(p.y() - hy) <= 9:
                return name
        if self.sel.contains(p):
            return "move"
        return None

    def _cursor_for(self, action):
        return {
            "nw": Qt.SizeFDiagCursor, "se": Qt.SizeFDiagCursor,
            "ne": Qt.SizeBDiagCursor, "sw": Qt.SizeBDiagCursor,
            "n": Qt.SizeVerCursor, "s": Qt.SizeVerCursor,
            "e": Qt.SizeHorCursor, "w": Qt.SizeHorCursor,
            "move": Qt.SizeAllCursor,
        }.get(action, Qt.CrossCursor)

    # ---------- 鼠标 ----------
    def mousePressEvent(self, e):
        p = e.position().toPoint()
        if e.button() == Qt.LeftButton:
            # 点完成按钮？
            if not self.sel.isNull() and self._btn_rect().contains(p):
                self._confirm()
                return
            action = self._hit_test(p)
            if action:
                self.mode = "adjust"
                self._action = action
                self._orig = QRect(self.sel.normalized())
                self._start = p
            else:
                self.mode = "select"
                self._origin = p
                self.sel = QRect(p, p)
            self.update()

    def mouseMoveEvent(self, e):
        p = e.position().toPoint()
        if self.mode == "select" and self._origin is not None:
            self.sel = QRect(self._origin, p).normalized()
        elif self.mode == "adjust" and self._start is not None:
            dx = p.x() - self._start.x()
            dy = p.y() - self._start.y()
            r = QRect(self._orig)
            a = self._action
            if a == "move":
                r.translate(dx, dy)
            else:
                if "n" in a:
                    r.setTop(r.top() + dy)
                if "s" in a:
                    r.setBottom(r.bottom() + dy)
                if "w" in a:
                    r.setLeft(r.left() + dx)
                if "e" in a:
                    r.setRight(r.right() + dx)
                r = r.normalized()
            self.sel = r
        else:
            # 悬停光标
            self.setCursor(self._cursor_for(self._hit_test(p)))
        self.update()

    def mouseReleaseEvent(self, e):
        if self.mode == "select":
            self._origin = None
            r = self.sel.normalized()
            if r.width() < MIN_SEL or r.height() < MIN_SEL:
                self.sel = QRect()
                self.mode = "idle"
            else:
                self.mode = "adjust"
        elif self.mode == "adjust":
            self._action = None
            self._start = None
        self.update()

    def mouseDoubleClickEvent(self, e):
        if self._hit_test(e.position().toPoint()) == "move":
            self._confirm()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
        elif e.key() in (Qt.Key_Return, Qt.Key_Enter):
            r = self.sel.normalized()
            if r.isNull() or r.width() < MIN_SEL or r.height() < MIN_SEL:
                self.sel = self.rect()  # 无选区 → 整屏
            self._confirm()

    def _btn_rect(self):
        """确认按钮（选区右下外侧）"""
        r = self.sel.normalized()
        bw, bh = 96, 34
        x = min(max(r.right() - bw, 8), self.width() - bw - 8)
        y = min(r.bottom() + 10, self.height() - bh - 8)
        return QRect(x, y, bw, bh)

    # ---------- 完成 ----------
    def _confirm(self):
        r = self.sel.normalized()
        if r.isNull() or r.width() < MIN_SEL or r.height() < MIN_SEL:
            return
        # widget(逻辑) → 原图(物理) 等比映射
        sx = self.full_pix.width() / max(self.width(), 1)
        sy = self.full_pix.height() / max(self.height(), 1)
        img_rect = QRect(int(r.x() * sx), int(r.y() * sy),
                         int(r.width() * sx), int(r.height() * sy))
        crop = self.full_pix.copy(img_rect)
        self.close()
        if self.on_done:
            self.on_done(crop)

    # ---------- 绘制 ----------
    def paintEvent(self, e):
        p = QPainter(self)
        p.drawPixmap(self.rect(), self.full_pix)
        r = self.sel.normalized()

        # 遮罩
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0, 90))
        full = self.rect()
        if not r.isNull():
            for part in (
                QRect(full.left(), full.top(), full.width(), r.top() - full.top()),
                QRect(full.left(), r.bottom(), full.width(), full.bottom() - r.bottom() + 1),
                QRect(full.left(), r.top(), r.left() - full.left(), r.height()),
                QRect(r.right(), r.top(), full.right() - r.right() + 1, r.height()),
            ):
                if part.isValid():
                    p.drawRect(part)
        else:
            p.drawRect(full)

        # 提示条（未选时）
        if r.isNull():
            p.setRenderHint(QPainter.Antialiasing)
            tip = "拖拽选择区域 · 松开后可拖动/拉手柄调整 · Enter 截取当前选区(无选区=整屏) · Esc 取消"
            f = QFont("Microsoft YaHei UI", 10)
            p.setFont(f)
            tw = p.fontMetrics().horizontalAdvance(tip) + 28
            pill = QRect((self.width() - tw) // 2, 24, tw, 32)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(20, 20, 22, 210))
            p.drawRoundedRect(pill, 16, 16)
            p.setPen(QColor(245, 245, 247))
            p.drawText(pill, Qt.AlignCenter, tip)
            p.end()
            return

        p.setRenderHint(QPainter.Antialiasing)
        # 选区边框：白外圈 + 蓝内圈
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(255, 255, 255, 200), 3))
        p.drawRect(r.adjusted(-1, -1, 1, 1))
        p.setPen(QPen(QColor(ACCENT), 1.6))
        p.drawRect(r)

        # 手柄：白色圆点
        p.setPen(QPen(QColor(ACCENT), 1.6))
        p.setBrush(QColor(255, 255, 255))
        for hx, hy in self._handles().values():
            p.drawEllipse(hx - 5, hy - 5, 10, 10)

        # 尺寸标签
        f = QFont("Microsoft YaHei UI", 9)
        p.setFont(f)
        label = f"{r.width()} × {r.height()}"
        tw = p.fontMetrics().horizontalAdvance(label) + 16
        pill = QRect(min(max(r.left(), 8), self.width() - tw - 8),
                     max(r.top() - 30, 6), tw, 22)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(20, 20, 22, 210))
        p.drawRoundedRect(pill, 11, 11)
        p.setPen(QColor(245, 245, 247))
        p.drawText(pill, Qt.AlignCenter, label)

        # 完成按钮
        b = self._btn_rect()
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(ACCENT))
        p.drawRoundedRect(b, 17, 17)
        p.setPen(QColor(255, 255, 255))
        bf = QFont("Microsoft YaHei UI", 10)
        bf.setBold(True)
        p.setFont(bf)
        p.drawText(b, Qt.AlignCenter, "完成 ⏎")
        p.end()
