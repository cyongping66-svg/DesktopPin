# -*- coding: utf-8 -*-
"""v16：启动时的「过去的备忘」提醒窗。
开机自启（或开启了启动提醒）时，程序先打开一个空白便签，再弹此窗，
粗略列出过去每条备忘的时间 + 首行摘要，勾选后可一键全部打开。
"""
import glob
import os
import time

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QTextDocument
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QScrollArea, QCheckBox, QApplication,
)

import config

ACCENT = "#6b5ce7"

STYLE_ISLAND = "QFrame{background:#2a2a2e;border-radius:22px;border:none;}"
STYLE_HEAD = "QFrame{background:#ffffff;border-radius:20px;border:none;}"
STYLE_CARD = "QFrame{background:#ffffff;border-radius:18px;border:none;}"

STYLE_TITLE = ("QLabel{color:#1d1d1f;font-size:16px;font-weight:700;"
               "background:transparent;}")
STYLE_DESC = "QLabel{color:#6e6e73;font-size:12px;background:transparent;}"

STYLE_CHECK = (
    "QCheckBox{color:#1d1d1f;font-size:12.5px;spacing:9px;"
    "background:transparent;padding:5px 2px;}"
    "QCheckBox::indicator{width:18px;height:18px;border-radius:6px;"
    "border:1.5px solid #c7c7cc;background:#f0eefb;}"
    f"QCheckBox::indicator:hover{{border-color:{ACCENT};background:#e9e5fa;}}"
    f"QCheckBox::indicator:checked{{background:{ACCENT};border-color:{ACCENT};}}")

STYLE_BTN_PRIMARY = (
    f"QPushButton{{background:{ACCENT};color:white;font-weight:600;"
    "border:none;border-radius:11px;padding:8px 16px;font-size:13px;}"
    "QPushButton:hover{background:#5848c9;}"
    "QPushButton:disabled{background:#d8d4f0;color:#ffffff;}")
STYLE_BTN_PLAIN = (
    "QPushButton{background:#f0eefb;color:#4a3fb8;border:none;"
    "border-radius:11px;padding:8px 16px;font-size:13px;}"
    "QPushButton:hover{background:#e3dff8;}")


def collect_past_memos(limit: int = 30):
    """返回 [(memo_id, 'MM-DD HH:MM', 摘要), ...]，按修改时间倒序"""
    out = []
    files = glob.glob(os.path.join(config.memos_dir(), "memo_*.html"))
    files += glob.glob(os.path.join(config.memos_dir(), "memo_*.txt"))
    try:
        files.sort(key=os.path.getmtime, reverse=True)
    except OSError:
        pass
    for f in files:
        base = os.path.basename(f)
        mid = base[5:].rsplit(".", 1)[0]
        try:
            with open(f, encoding="utf-8") as fh:
                raw = fh.read()
            if f.endswith(".txt"):
                preview = raw
            else:
                doc = QTextDocument()
                doc.setHtml(raw)
                preview = doc.toPlainText()
        except OSError:
            preview = ""
        preview = " ".join(preview.split())[:40] or "（图片）"
        ts = time.strftime("%m-%d %H:%M", time.localtime(os.path.getmtime(f)))
        out.append((mid, ts, preview))
        if len(out) >= limit:
            break
    return out


class StartupReminder(QWidget):
    """启动提醒：粗略展示过去的备忘，勾选后打开"""

    def __init__(self, items=None, on_open=None):
        super().__init__(None, Qt.FramelessWindowHint
                         | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.on_open = on_open
        self.items = items if items is not None else collect_past_memos()
        self.checks = []
        self._drag = None

        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedWidth(470)
        f = QFont()
        f.setFamilies(["Microsoft YaHei UI", "Segoe UI Emoji", "Segoe UI"])
        f.setPointSize(10)
        self.setFont(f)

        island = QFrame()
        island.setStyleSheet(STYLE_ISLAND)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(island)
        outer = QVBoxLayout(island)
        outer.setContentsMargins(16, 14, 16, 16)
        outer.setSpacing(10)

        # 头部白胶囊
        head_frame = QFrame()
        head_frame.setStyleSheet(STYLE_HEAD)
        head_frame.setFixedHeight(46)
        head = QHBoxLayout(head_frame)
        head.setContentsMargins(16, 0, 8, 0)
        head.addWidget(self._lbl("打开过去的备忘？", STYLE_TITLE))
        head.addStretch()
        btn_close = QPushButton("✕")
        btn_close.setFixedSize(28, 28)
        btn_close.setCursor(Qt.PointingHandCursor)
        btn_close.setStyleSheet(
            "QPushButton{background:#e5e5ea;color:#1d1d1f;border:none;"
            "border-radius:14px;padding:0;font-size:12px;}"
            "QPushButton:hover{background:#d1d1d6;}")
        head.addWidget(btn_close)
        outer.addWidget(head_frame)
        btn_close.clicked.connect(self.close)

        # 白色内容卡
        card = QFrame()
        card.setStyleSheet(STYLE_CARD)
        cv = QVBoxLayout(card)
        cv.setContentsMargins(16, 12, 16, 12)
        cv.setSpacing(6)
        cv.addWidget(self._lbl(
            f"共 {len(self.items)} 条备忘，勾选后点下方按钮打开：", STYLE_DESC))

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        scroll.setStyleSheet(
            "QScrollArea{background:transparent;border:none;}"
            "QScrollBar:vertical{background:transparent;width:7px;}"
            "QScrollBar::handle:vertical{background:#d5d2e8;border-radius:3px;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical"
            "{height:0;}"
            "QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical"
            "{background:transparent;}")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        holder = QWidget()
        holder.setStyleSheet("QWidget{background:transparent;}")
        hb = QVBoxLayout(holder)
        hb.setContentsMargins(0, 0, 6, 0)
        hb.setSpacing(1)
        for mid, ts, preview in self.items:
            cb = QCheckBox(f"{ts}   {preview}")
            cb.setStyleSheet(STYLE_CHECK)
            cb.setCursor(Qt.PointingHandCursor)
            cb.setChecked(True)
            cb.toggled.connect(self._update_count)
            hb.addWidget(cb)
            self.checks.append((mid, cb))
        hb.addStretch()
        scroll.setWidget(holder)
        scroll.setMinimumHeight(min(240, max(60, len(self.items) * 32)))
        cv.addWidget(scroll, 1)

        row = QHBoxLayout()
        self.cb_all = QCheckBox("全选")
        self.cb_all.setStyleSheet(STYLE_CHECK)
        self.cb_all.setCursor(Qt.PointingHandCursor)
        self.cb_all.setChecked(True)
        self.cb_all.toggled.connect(self._toggle_all)
        row.addWidget(self.cb_all)
        row.addStretch()
        btn_skip = QPushButton("跳过")
        btn_skip.setStyleSheet(STYLE_BTN_PLAIN)
        btn_skip.setCursor(Qt.PointingHandCursor)
        self.btn_open = QPushButton()
        self.btn_open.setStyleSheet(STYLE_BTN_PRIMARY)
        self.btn_open.setCursor(Qt.PointingHandCursor)
        row.addWidget(btn_skip)
        row.addWidget(self.btn_open)
        cv.addLayout(row)
        outer.addWidget(card, 1)

        btn_skip.clicked.connect(self.close)
        self.btn_open.clicked.connect(self._open_selected)
        self._update_count()

        self.adjustSize()
        self._center()

    # ---------- 内部 ----------
    @staticmethod
    def _lbl(text, style):
        lbl = QLabel(text)
        lbl.setStyleSheet(style)
        return lbl

    def _center(self):
        sg = (QApplication.primaryScreen() or self.screen()).availableGeometry()
        self.move(sg.center().x() - self.width() // 2,
                  sg.center().y() - self.height() // 2)

    def _selected(self):
        return [mid for mid, cb in self.checks if cb.isChecked()]

    def _update_count(self):
        n = len(self._selected())
        self.btn_open.setText(f"打开选中（{n}）" if n else "打开选中")
        self.btn_open.setEnabled(n > 0)
        if self.checks:
            all_on = n == len(self.checks)
            self.cb_all.blockSignals(True)
            self.cb_all.setChecked(all_on)
            self.cb_all.blockSignals(False)

    def _toggle_all(self, on):
        for _, cb in self.checks:
            cb.blockSignals(True)
            cb.setChecked(on)
            cb.blockSignals(False)
        self._update_count()

    def _open_selected(self):
        ids = self._selected()
        self.close()
        if self.on_open and ids:
            self.on_open(ids)

    # ---------- 拖动 ----------
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()
