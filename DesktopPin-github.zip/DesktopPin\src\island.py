# -*- coding: utf-8 -*-
"""悬浮岛设置窗（SwiftUI 分区卡片式）：
外观 / 闹钟 / AI 助手 / 快捷键
v9：所有控件改为逐控件内联样式（打包 exe 后 objectName 选择器不可靠）；
复选框选中态改纯 CSS 填充（内置图片资源在打包环境会失效）。
"""
import os
import shutil
import glob
import time

from PySide6.QtCore import Qt
from PySide6.QtGui import QKeySequence, QTextDocument, QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSlider,
    QFrame, QKeySequenceEdit, QCheckBox, QApplication, QFileDialog,
    QLineEdit, QScrollArea, QSizePolicy, QRadioButton,
)

import config
from winutils import is_conflicted, set_autostart, is_autostart_enabled
from toast import show_toast
from alarm import AlarmDialog, RINGTONES
from ai_service import AiWorker, collect_memo_texts
from pin_window import OcrResultDialog
from memo import ToggleSwitch

ACCENT = "#6b5ce7"   # v12：参考设计稿主色（紫）

_KEY_LABEL = {"ctrl": "Ctrl", "alt": "Alt", "shift": "Shift", "win": "Meta"}

# 仅保留滚动条等通用件的窗口级样式；卡片/按钮/输入框全部逐控件内联
ISLAND_QSS = f"""
    QScrollArea {{ border: none; background: transparent; }}
    QScrollBar:vertical {{ background: transparent; width: 8px; }}
    QScrollBar::handle:vertical {{ background: #b9b9be; border-radius: 4px; }}
    QScrollBar::handle:vertical:hover {{ background: #8e8e93; }}
"""

# ---------- 逐控件内联样式（不依赖 objectName / 图片资源） ----------
# v12 参考设计稿：深炭底 + 白色圆角卡 + 紫色主色
STYLE_ISLAND = ("QFrame{background:#242428;border-radius:24px;border:none;}")
STYLE_CARD = ("QFrame{background:#ffffff;border-radius:16px;border:none;}")

_LBL_STYLES = {
    "title": "QLabel{color:#1d1d1f;font-size:16px;font-weight:700;"
             "background:transparent;}",
    "sec":    "QLabel{color:#1d1d1f;font-size:15px;font-weight:700;"
              "background:transparent;}",
    "desc":   "QLabel{color:#3a3a3c;font-size:12px;background:transparent;}",
    "caption": "QLabel{color:#6e6e73;font-size:11px;font-weight:600;"
               "background:transparent;}",
    "val":    "QLabel{color:#1d1d1f;font-size:13px;font-weight:600;"
              "background:transparent;}",
    "plain":  "QLabel{color:#1d1d1f;font-size:13px;background:transparent;}",
}

_BTN_STYLES = {
    "normal": (
        "QPushButton{background:#f0eefb;color:#4a3fb8;"
        "border:none;border-radius:11px;"
        "padding:8px 16px;font-size:13px;}"
        "QPushButton:hover{background:#e3dff8;}"
        f"QPushButton:checked{{background:{ACCENT};color:white;}}"),
    "primary": (
        f"QPushButton{{background:{ACCENT};color:white;font-weight:600;"
        "border:none;border-radius:11px;"
        "padding:8px 16px;font-size:13px;}"
        "QPushButton:hover{background:#5848c9;color:white;}"),
    "danger": (
        "QPushButton{background:rgba(255,59,48,26);color:#d70015;"
        "border:none;border-radius:11px;"
        "padding:8px 16px;font-size:13px;}"
        "QPushButton:hover{background:#ff3b30;color:white;}"),
}

STYLE_INPUT = (
    "QLineEdit{background:#f0eefb;color:#1d1d1f;"
    "border:1.5px solid transparent;border-radius:10px;"
    "padding:4px 10px;font-size:13px;}"
    f"QLineEdit:focus{{border:1.5px solid {ACCENT};background:white;}}")

STYLE_KSE = (
    # 注意：QKeySequenceEdit 内部有 QLineEdit 子控件，外层选择器管不到它；
    # 深色 Windows 下调色板文字为白色 → 白字落在浅底上「隐形」。
    # 必须给内部 QLineEdit 显式写死文字色。
    "QKeySequenceEdit{background:#f0eefb;color:#1d1d1f;"
    "border:1.5px solid transparent;border-radius:10px;"
    "padding:5px 9px;font-size:13px;min-height:22px;}"
    f"QKeySequenceEdit:focus{{border:1.5px solid {ACCENT};background:white;}}"
    "QLineEdit{background:transparent;color:#1d1d1f;border:none;}")

STYLE_CHECK = (
    "QCheckBox{color:#1d1d1f;font-size:12px;spacing:7px;background:transparent;}"
    "QCheckBox::indicator{width:18px;height:18px;border-radius:6px;"
    "border:1.5px solid #c7c7cc;background:#f0eefb;}"
    f"QCheckBox::indicator:hover{{border-color:{ACCENT};background:#e9e5fa;}}"
    f"QCheckBox::indicator:checked{{background:{ACCENT};"
    f"border-color:{ACCENT};}}")

STYLE_RADIO = (
    "QRadioButton{color:#1d1d1f;font-size:13px;spacing:8px;background:transparent;}"
    "QRadioButton::indicator{width:16px;height:16px;border-radius:8px;"
    "border:1.5px solid #c7c7cc;background:white;}"
    f"QRadioButton::indicator:hover{{border-color:{ACCENT};}}"
    f"QRadioButton::indicator:checked{{background:{ACCENT};"
    f"border:2px solid {ACCENT};}}")

STYLE_SLIDER = (
    f"QSlider::groove:horizontal{{height:5px;background:#e5e5ea;"
    f"border-radius:3px;}}"
    f"QSlider::sub-page:horizontal{{background:{ACCENT};border-radius:3px;}}"
    "QSlider::handle:horizontal{width:18px;height:18px;margin:-7px 0;"
    "border-radius:9px;background:white;"
    "border:1px solid rgba(0,0,0,26);}"
    f"QSlider::handle:horizontal:hover{{border:1.5px solid {ACCENT};}}")


def _lbl(text="", kind="plain"):
    lbl = QLabel(text)
    lbl.setStyleSheet(_LBL_STYLES[kind])
    if kind in ("desc", "caption"):
        lbl.setWordWrap(True)
    return lbl


def _field(caption, editor):
    """标题在上、输入框占满一行，避免标签和输入挤在同一行。"""
    box = QVBoxLayout()
    box.setSpacing(4)
    box.addWidget(_lbl(caption, "caption"))
    editor.setFixedHeight(36)
    box.addWidget(editor)
    return box


def _btn(text, kind="normal", checkable=False, tip=None):
    b = QPushButton(text)
    b.setCheckable(checkable)
    b.setStyleSheet(_BTN_STYLES[kind])
    b.setCursor(Qt.PointingHandCursor)
    if tip:
        b.setToolTip(tip)
    return b


def hotkey_to_qks(hk: str) -> QKeySequence:
    parts = [p.strip().lower() for p in hk.split("+") if p.strip()]
    if not parts:
        return QKeySequence()
    mods = [_KEY_LABEL[p] for p in parts[:-1] if p in _KEY_LABEL]
    key = parts[-1]
    if len(key) == 1:
        key = key.upper()
    else:
        key = key[0].upper() + key[1:]
    return QKeySequence("+".join(mods + [key]))


def seq_to_hotkey(seq: QKeySequence) -> str:
    parts = [p.strip().lower() for p in seq.toString().split("+") if p.strip()]
    parts = ["win" if p == "meta" else p for p in parts]
    return "+".join(parts)


def _card(title=None):
    """返回 (card_frame, inner_vbox)"""
    card = QFrame()
    card.setStyleSheet(STYLE_CARD)
    v = QVBoxLayout(card)
    v.setContentsMargins(18, 14, 18, 16)
    v.setSpacing(12)
    if title:
        v.addWidget(_lbl(title, "sec"))
    return card, v


class HistoryWindow(QWidget):
    """历史便签存档：恢复 / 删除"""

    def __init__(self):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setMinimumWidth(360)
        self.setStyleSheet(ISLAND_QSS)

        island = QFrame()
        # 历史窗用浅色底（内容文字为深色；主设置岛是深炭底）
        island.setStyleSheet(
            "QFrame{background:rgba(246,247,250,255);border-radius:22px;"
            "border:none;}")
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(island)
        v = QVBoxLayout(island)
        v.setContentsMargins(18, 14, 18, 18)
        v.setSpacing(8)

        head = QHBoxLayout()
        head.addWidget(_lbl("🗂  历史便签", "title"))
        head.addStretch()
        btn_close = _btn("✕")
        btn_close.setFixedSize(26, 26)
        btn_close.setStyleSheet(
            "QPushButton{background:#e5e5ea;color:#1d1d1f;border:none;"
            "border-radius:13px;padding:0;font-size:12px;}"
            "QPushButton:hover{background:#d1d1d6;}")
        head.addWidget(btn_close)
        v.addLayout(head)
        btn_close.clicked.connect(self.close)

        self.list_v = v
        self._build()
        self.adjustSize()
        g = QApplication.primaryScreen().availableGeometry()
        self.move(g.center().x() - self.width() // 2,
                  g.center().y() - self.height() // 2)

    def _build(self):
        while self.list_v.count() > 1:
            item = self.list_v.takeAt(1)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                _clear_layout(item.layout())

        files = sorted(glob.glob(os.path.join(config.history_dir(), "memo_*.html")),
                       key=os.path.getmtime, reverse=True)
        if not files:
            self.list_v.addWidget(_lbl("暂无历史便签（✕ 关闭的便签会存档到这里）", "desc"))
            return

        for f in files[:20]:
            row = QHBoxLayout()
            mid = os.path.basename(f)[5:-5]
            try:
                with open(f, encoding="utf-8") as fh:
                    doc = QTextDocument()
                    doc.setHtml(fh.read())
                    preview = doc.toPlainText().strip().split("\n")[0][:24] or "（图片）"
            except OSError:
                preview = "（读取失败）"
            ts = time.strftime("%m-%d %H:%M", time.localtime(os.path.getmtime(f)))
            row.addWidget(_lbl(f"{ts}  {preview}", "desc"), 1)
            btn_restore = _btn("恢复", "primary")
            btn_del = _btn("删除", "danger")
            btn_restore.setFixedWidth(60)
            btn_del.setFixedWidth(60)
            row.addWidget(btn_restore)
            row.addWidget(btn_del)
            self.list_v.addLayout(row)
            btn_restore.clicked.connect(lambda _=False, m=mid: self._restore(m))
            btn_del.clicked.connect(lambda _=False, m=mid: self._delete(m))

    def _restore(self, memo_id):
        import memo as memo_mod
        src = config.memo_file(memo_id, "html", archived=True)
        if os.path.exists(src):
            shutil.move(src, config.memo_file(memo_id, "html"))
        if memo_mod.open_memo:
            memo_mod.open_memo(memo_id)
        show_toast("便签已恢复")
        self._rebuild()

    def _delete(self, memo_id):
        try:
            os.remove(config.memo_file(memo_id, "html", archived=True))
        except OSError:
            pass
        show_toast("已删除")
        self._rebuild()

    def _rebuild(self):
        self._build()
        self.adjustSize()


def _clear_layout(lay):
    while lay.count():
        it = lay.takeAt(0)
        if it.widget():
            it.widget().deleteLater()
        elif it.layout():
            _clear_layout(it.layout())


class SettingsIsland(QWidget):
    """悬浮岛设置窗口（单例，由 main 管理）"""

    def __init__(self, on_applied, alarm_manager=None, parent=None):
        super().__init__(parent)
        self.on_applied = on_applied
        self.alarm_manager = alarm_manager
        self._drag = None
        self._history = None
        self._ai_worker = None

        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setMinimumWidth(460)
        # 字体回退：中文 + Emoji 都能显示
        _f = QFont()
        _f.setFamilies(["Microsoft YaHei UI", "Segoe UI Emoji", "Segoe UI"])
        _f.setPointSize(10)
        self.setFont(_f)

        island = QFrame()
        island.setStyleSheet(STYLE_ISLAND)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(island)

        outer = QVBoxLayout(island)
        outer.setContentsMargins(14, 12, 14, 14)
        outer.setSpacing(12)

        # 头部（v12：白色胶囊标题栏，可拖动）
        head_frame = QFrame()
        head_frame.setStyleSheet(
            "QFrame{background:#ffffff;border-radius:20px;border:none;}")
        head_frame.setFixedHeight(44)
        head = QHBoxLayout(head_frame)
        head.setContentsMargins(16, 0, 8, 0)
        head.addWidget(_lbl("设置", "title"))
        head.addStretch()
        btn_close = _btn("✕")
        btn_close.setFixedSize(28, 28)
        btn_close.setStyleSheet(
            "QPushButton{background:#e5e5ea;color:#1d1d1f;border:none;"
            "border-radius:14px;padding:0;font-size:12px;}"
            "QPushButton:hover{background:#d1d1d6;}")
        head.addWidget(btn_close)
        outer.addWidget(head_frame)
        btn_close.clicked.connect(self.hide)

        # 滚动区
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")
        body = QWidget()
        body.setStyleSheet("QWidget{background:transparent;}")
        self.setStyleSheet(ISLAND_QSS)
        v = QVBoxLayout(body)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(12)
        scroll.setWidget(body)
        outer.addWidget(scroll, 1)

        # ===== 卡片：外观 =====
        card, cv = _card("外观")
        row_theme = QHBoxLayout()
        row_theme.setSpacing(20)
        self.btn_dark = QRadioButton("深色")
        self.btn_light = QRadioButton("浅色")
        for r in (self.btn_dark, self.btn_light):
            r.setStyleSheet(STYLE_RADIO)
            r.setCursor(Qt.PointingHandCursor)
        row_theme.addWidget(self.btn_dark)
        row_theme.addWidget(self.btn_light)
        row_theme.addStretch()
        cv.addLayout(row_theme)
        row_op = QHBoxLayout()
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setStyleSheet(STYLE_SLIDER)
        self.slider.setRange(50, 100)
        self.lbl_opacity = _lbl("100%", "val")
        self.lbl_opacity.setFixedWidth(44)
        row_op.addWidget(self.slider, 1)
        row_op.addWidget(self.lbl_opacity)
        cv.addLayout(row_op)
        v.addWidget(card)
        self.btn_dark.clicked.connect(lambda: self._set_theme("dark"))
        self.btn_light.clicked.connect(lambda: self._set_theme("light"))
        self.slider.valueChanged.connect(self._on_opacity)

        # ===== 卡片：启动（v16 开机自启动 / 启动提醒） =====
        card, cv = _card("启动")
        row_auto = QHBoxLayout()
        row_auto.addWidget(_lbl("开机自启动"))
        row_auto.addStretch()
        self.sw_autostart = ToggleSwitch(False)
        self.sw_autostart.setToolTip("开机后自动运行 DesktopPin")
        row_auto.addWidget(self.sw_autostart)
        cv.addLayout(row_auto)
        cv.addWidget(_lbl("开机后自动运行，并打开一个空白便签", "desc"))
        row_rem = QHBoxLayout()
        row_rem.addWidget(_lbl("启动时提醒过去的备忘"))
        row_rem.addStretch()
        self.sw_remind = ToggleSwitch(True)
        self.sw_remind.setToolTip("启动时列出过去的备忘，勾选后可一键打开")
        row_rem.addWidget(self.sw_remind)
        cv.addLayout(row_rem)
        cv.addWidget(_lbl("列出过去的备忘摘要，勾选后一键打开", "desc"))
        v.addWidget(card)
        self.sw_autostart.toggled.connect(self._on_autostart)
        self.sw_remind.toggled.connect(self._on_remind)

        # ===== 卡片：闹钟 =====
        card, cv = _card("闹钟")
        row_new = QHBoxLayout()
        btn_new_alarm = _btn("＋ 新建闹钟", "primary")
        row_new.addWidget(btn_new_alarm)
        row_new.addStretch()
        cv.addLayout(row_new)
        self.alarm_list = QVBoxLayout()
        self.alarm_list.setSpacing(4)
        cv.addLayout(self.alarm_list)
        v.addWidget(card)
        btn_new_alarm.clicked.connect(self._new_alarm)

        # ===== 卡片：AI 助手 =====
        card, cv = _card("AI 助手")
        cv.addWidget(_lbl("接入 OpenAI 兼容接口（DeepSeek / 通义 / Kimi 等）", "desc"))
        self.ai_base = QLineEdit()
        self.ai_base.setStyleSheet(STYLE_INPUT)
        self.ai_base.setPlaceholderText("https://api.deepseek.com/v1")
        cv.addLayout(_field("接口地址", self.ai_base))
        self.ai_key = QLineEdit()
        self.ai_key.setStyleSheet(STYLE_INPUT)
        self.ai_key.setEchoMode(QLineEdit.Password)
        self.ai_key.setPlaceholderText("sk-…")
        cv.addLayout(_field("API Key", self.ai_key))
        self.ai_model = QLineEdit()
        self.ai_model.setStyleSheet(STYLE_INPUT)
        self.ai_model.setPlaceholderText("deepseek-chat")
        cv.addLayout(_field("模型", self.ai_model))
        r4 = QHBoxLayout()
        btn_ai_save = _btn("保存配置")
        btn_ai = _btn("✨ AI 总结全部便签", "primary")
        r4.addWidget(btn_ai_save)
        r4.addStretch()
        r4.addWidget(btn_ai)
        cv.addLayout(r4)
        v.addWidget(card)
        btn_ai_save.clicked.connect(self._save_ai)
        btn_ai.clicked.connect(self._run_ai)

        # ===== 卡片：保存方式（本地 / 飞书，勾哪个用哪个，可同时勾） =====
        card, cv = _card("保存方式")
        cv.addWidget(_lbl("点便签上的「保存」时，按下面勾选的方式保存，两项可以同时勾。", "desc"))

        self.cb_save_local = QCheckBox("保存到本地")
        self.cb_save_local.setStyleSheet(STYLE_CHECK + "QCheckBox{font-size:13px;font-weight:600;}")
        self.cb_save_local.setCursor(Qt.PointingHandCursor)
        cv.addWidget(self.cb_save_local)
        self.box_local = QWidget()
        self.box_local.setStyleSheet("QWidget{background:transparent;}")
        lv = QVBoxLayout(self.box_local)
        lv.setContentsMargins(25, 0, 0, 0)
        lv.setSpacing(8)
        lv.addWidget(_lbl("整条便签（含图片）存成一个网页文件；同一条再次保存会直接覆盖上一份。", "desc"))
        self.local_dir = QLineEdit()
        self.local_dir.setStyleSheet(STYLE_INPUT)
        self.local_dir.setReadOnly(True)
        lv.addLayout(_field("保存位置", self.local_dir))
        row_local = QHBoxLayout()
        btn_open_dir = _btn("打开文件夹")
        btn_pick_dir = _btn("更改位置")
        row_local.addWidget(btn_open_dir)
        row_local.addStretch()
        row_local.addWidget(btn_pick_dir)
        lv.addLayout(row_local)
        cv.addWidget(self.box_local)
        btn_open_dir.clicked.connect(self._open_backup_dir)
        btn_pick_dir.clicked.connect(self._pick_backup_dir)

        self.cb_save_fs = QCheckBox("同步到飞书文档")
        self.cb_save_fs.setStyleSheet(STYLE_CHECK + "QCheckBox{font-size:13px;font-weight:600;}")
        self.cb_save_fs.setCursor(Qt.PointingHandCursor)
        cv.addWidget(self.cb_save_fs)
        self.box_fs = QWidget()
        self.box_fs.setStyleSheet("QWidget{background:transparent;}")
        cv_outer = cv
        cv = QVBoxLayout(self.box_fs)
        cv.setContentsMargins(25, 0, 0, 0)
        cv.setSpacing(8)
        cv.addWidget(_lbl("不用登录飞书。保存会追加到这篇文档，不同日期之间空两行。", "desc"))
        self.fs_url = QLineEdit()
        self.fs_url.setStyleSheet(STYLE_INPUT)
        self.fs_url.setPlaceholderText("https://xxx.feishu.cn/wiki/… 或 /docx/…")
        cv.addLayout(_field("文档链接", self.fs_url))
        self.fs_id = QLineEdit()
        self.fs_id.setStyleSheet(STYLE_INPUT)
        self.fs_id.setPlaceholderText("cli_…")
        cv.addLayout(_field("App ID", self.fs_id))
        self.fs_secret = QLineEdit()
        self.fs_secret.setStyleSheet(STYLE_INPUT)
        self.fs_secret.setEchoMode(QLineEdit.Password)
        self.fs_secret.setPlaceholderText("应用凭证")
        cv.addLayout(_field("App Secret", self.fs_secret))
        row_fs = QHBoxLayout()
        btn_fs = _btn("保存配置")
        btn_fs_test = _btn("测试连接", "primary")
        row_fs.addWidget(btn_fs)
        row_fs.addStretch()
        row_fs.addWidget(btn_fs_test)
        cv.addLayout(row_fs)
        cv_outer.addWidget(self.box_fs)
        v.addWidget(card)
        btn_fs.clicked.connect(self._save_feishu)
        btn_fs_test.clicked.connect(self._test_feishu)
        self._fs_probe = None
        self.cb_save_local.toggled.connect(self._save_mode_changed)
        self.cb_save_fs.toggled.connect(self._save_mode_changed)

        # ===== 卡片：快捷键（v9：仅保留 截图贴图 / 锁定解锁 两项） =====
        card, cv = _card("快捷键")
        cv.addWidget(_lbl("点击输入框后直接按组合键", "desc"))
        self.kse = {}
        self.cb_share = {}
        for action, name in config.ACTION_NAMES.items():
            row = QHBoxLayout()
            row.setSpacing(8)
            lbl = _lbl(name)
            kse = QKeySequenceEdit()
            kse.setStyleSheet(STYLE_KSE)
            kse.setMinimumHeight(36)
            cb = QCheckBox("与其他软件共用")
            cb.setStyleSheet(STYLE_CHECK)
            row.addWidget(lbl)
            row.addWidget(kse, 1)
            row.addWidget(cb)
            cv.addLayout(row)
            self.kse[action] = kse
            self.cb_share[action] = cb
        btn_apply = _btn("应用快捷键", "primary")
        cv.addWidget(btn_apply, 0, Qt.AlignRight)
        btn_apply.clicked.connect(self._apply_hotkeys)
        v.addWidget(card)

        # ===== 卡片：便签 =====
        # 已按需求剔除「🗂 便签」卡片（历史便签 / 同步目录入口不再展示）

        self.refresh()
        self.adjustSize()

    # ---------- 定位 ----------
    def place(self, anchor=None):
        self.adjustSize()
        if anchor is not None:
            try:
                anchor_geo = anchor.frameGeometry()
            except RuntimeError:
                anchor = None
        if anchor is not None:
            screen = anchor.screen() or QApplication.primaryScreen()
            sg = screen.availableGeometry()
            x = anchor_geo.left() - self.width() - 16
            if x < sg.left():
                x = anchor_geo.right() + 16
            y = min(max(anchor_geo.top(), sg.top()), sg.bottom() - self.height())
            self.move(x, y)
        else:
            sg = QApplication.primaryScreen().availableGeometry()
            self.move(sg.right() - self.width() - 24, sg.top() + 24)

    # ---------- 刷新 ----------
    def refresh(self):
        cfg = config.load()
        self.btn_dark.setChecked(cfg["theme"] == "dark")
        self.btn_light.setChecked(cfg["theme"] == "light")
        self.slider.blockSignals(True)
        self.slider.setValue(int(cfg["opacity"]))
        self.slider.blockSignals(False)
        self.lbl_opacity.setText(f"{int(cfg['opacity'])}%")
        for action, kse in self.kse.items():
            kse.setKeySequence(hotkey_to_qks(cfg["hotkeys"].get(action, "")))
            self.cb_share[action].setChecked(cfg["share"].get(action, False))
        ai = cfg.get("ai", {})
        self.ai_base.setText(ai.get("base_url", ""))
        self.ai_key.setText(ai.get("api_key", ""))
        self.ai_model.setText(ai.get("model", ""))
        fs = cfg.get("feishu") or {}
        self.fs_url.setText(fs.get("doc_url", ""))
        self.fs_id.setText(fs.get("app_id", ""))
        self.fs_secret.setText(fs.get("app_secret", ""))
        mode = cfg.get("save_to") or {}
        for cb, key in ((self.cb_save_local, "local"), (self.cb_save_fs, "feishu")):
            cb.blockSignals(True)
            cb.setChecked(bool(mode.get(key, True)))
            cb.blockSignals(False)
        self._set_section(self.box_local, self.cb_save_local.isChecked())
        self._set_section(self.box_fs, self.cb_save_fs.isChecked())
        self.local_dir.setText(cfg.get("backup_dir") or os.path.join(config.project_dir(), "backup"))
        # 自启动状态以注册表实际值为准（用户可能在外部工具里改过）
        self.sw_autostart.blockSignals(True)
        self.sw_autostart.setChecked(is_autostart_enabled())
        self.sw_autostart.blockSignals(False)
        self.sw_remind.blockSignals(True)
        self.sw_remind.setChecked(bool(cfg.get("startup_reminder", True)))
        self.sw_remind.blockSignals(False)
        self._refresh_alarms()

    # ---------- 外观 ----------
    def _set_theme(self, name):
        cfg = config.load()
        cfg["theme"] = name
        config.save(cfg)
        self.btn_dark.setChecked(name == "dark")
        self.btn_light.setChecked(name == "light")
        if self.on_applied:
            self.on_applied(cfg)
        show_toast(f"已切换{'深色' if name == 'dark' else '浅色'}主题")

    def _on_opacity(self, val):
        self.lbl_opacity.setText(f"{val}%")
        cfg = config.load()
        cfg["opacity"] = val
        config.save(cfg)
        if self.on_applied:
            self.on_applied(cfg)

    # ---------- 启动 ----------
    def _on_autostart(self, on):
        if not set_autostart(on):
            show_toast("设置失败：无法写入开机启动项，请重试", ok=False)
            self.sw_autostart.blockSignals(True)
            self.sw_autostart.setChecked(not on)
            self.sw_autostart.blockSignals(False)
            return
        cfg = config.load()
        cfg["autostart"] = on
        config.save(cfg)
        show_toast("已开启开机自启动" if on else "已关闭开机自启动")

    def _on_remind(self, on):
        cfg = config.load()
        cfg["startup_reminder"] = on
        config.save(cfg)
        show_toast("启动时会提醒过去的备忘" if on else "启动时不再提醒")

    # ---------- 闹钟 ----------
    def _refresh_alarms(self):
        while self.alarm_list.count():
            it = self.alarm_list.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                _clear_layout(it.layout())
        alarms = config.load().get("alarms", [])
        if not alarms:
            self.alarm_list.addWidget(_lbl("暂无闹钟", "desc"))
            return
        for a in alarms:
            row = QHBoxLayout()
            info = _lbl(f"{a['time']}　{a.get('label', '')}"
                        f"{'（每天）' if a.get('daily') else ''}", "val")
            sub = _lbl("已暂停" if not a.get('active', True)
                       else f"延时 {a.get('snooze', 3)} 分钟", "desc")
            sub.setFixedWidth(84)
            btn_toggle = _btn("启用" if not a.get("active", True) else "暂停")
            btn_toggle.setFixedWidth(56)
            btn_del = _btn("删除", "danger")
            btn_del.setFixedWidth(56)
            row.addWidget(info, 1)
            row.addWidget(sub)
            row.addWidget(btn_toggle)
            row.addWidget(btn_del)
            self.alarm_list.addLayout(row)
            btn_toggle.clicked.connect(
                lambda _=False, i=a["id"]: self._toggle_alarm(i))
            btn_del.clicked.connect(
                lambda _=False, i=a["id"]: self._del_alarm(i))

    def _new_alarm(self):
        dlg = AlarmDialog(self)
        if dlg.exec() == AlarmDialog.Accepted:
            alarm = dlg.alarm()
            if self.alarm_manager:
                self.alarm_manager.add(alarm)
            else:
                cfg = config.load()
                cfg.setdefault("alarms", []).append(alarm)
                config.save(cfg)
            self._refresh_alarms()
            show_toast(f"闹钟已添加：{alarm['time']} {alarm['label']}")

    def _toggle_alarm(self, alarm_id):
        if self.alarm_manager:
            self.alarm_manager.toggle(alarm_id)
        self._refresh_alarms()

    def _del_alarm(self, alarm_id):
        if self.alarm_manager:
            self.alarm_manager.remove(alarm_id)
        self._refresh_alarms()
        show_toast("闹钟已删除")

    # ---------- 保存方式 ----------
    @staticmethod
    def _set_section(box, on):
        """未勾选的方式整组变淡且不可点；样式表不管禁用态，所以用透明度效果。"""
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        box.setEnabled(on)
        eff = box.graphicsEffect()
        if eff is None:
            eff = QGraphicsOpacityEffect(box)
            box.setGraphicsEffect(eff)
        eff.setOpacity(1.0 if on else 0.35)

    def _save_mode_changed(self):
        local, fs = self.cb_save_local.isChecked(), self.cb_save_fs.isChecked()
        self._set_section(self.box_local, local)
        self._set_section(self.box_fs, fs)
        cfg = config.load()
        cfg["save_to"] = {"local": local, "feishu": fs}
        config.save(cfg)
        if not (local or fs):
            show_toast("两项都没勾，点「保存」将不会保存任何内容", ok=False)
        else:
            show_toast("保存方式：" + " + ".join(
                n for n, on in (("本地", local), ("飞书文档", fs)) if on))

    def _open_backup_dir(self):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        QDesktopServices.openUrl(QUrl.fromLocalFile(config.backup_dir()))

    def _pick_backup_dir(self):
        d = QFileDialog.getExistingDirectory(self, "选择本地保存位置", self.local_dir.text())
        if not d:
            return
        d = os.path.normpath(d)
        cfg = config.load()
        cfg["backup_dir"] = d
        config.save(cfg)
        self.local_dir.setText(d)
        show_toast("本地保存位置已更改")

    # ---------- AI ----------
    def _save_feishu(self):
        from feishu_sync import clear_token
        cfg = config.load()
        old = cfg.get("feishu") or {}
        url = self.fs_url.text().strip()
        app_id = self.fs_id.text().strip()
        secret = self.fs_secret.text().strip()
        same = (old.get("doc_url") == url and old.get("app_id") == app_id
                and old.get("app_secret") == secret)
        if not same:
            clear_token()
        cfg["feishu"] = {
            "app_id": app_id,
            "app_secret": secret,
            "doc_url": url,
            "document_id": old.get("document_id", "") if same else "",
            "doc_url_resolved": old.get("doc_url_resolved", "") if same else "",
        }
        config.save(cfg)
        show_toast("飞书配置已保存")

    def _test_feishu(self):
        from feishu_sync import FeishuProbeWorker
        self._save_feishu()
        if self._fs_probe is not None and self._fs_probe.isRunning():
            show_toast("正在测试连接，请稍候")
            return
        self._fs_probe = FeishuProbeWorker(self)
        self._fs_probe.done.connect(
            lambda title: show_toast(f"已连通飞书文档：{title}"))
        self._fs_probe.failed.connect(
            lambda err: show_toast(f"飞书连接失败：{err}", ok=False))
        self._fs_probe.start()
        show_toast("正在测试飞书连接…")

    def _save_ai(self):
        cfg = config.load()
        cfg["ai"] = {
            "base_url": self.ai_base.text().strip(),
            "api_key": self.ai_key.text().strip(),
            "model": self.ai_model.text().strip(),
        }
        config.save(cfg)
        show_toast("AI 配置已保存")

    def _run_ai(self):
        self._save_ai_silent()
        text = collect_memo_texts()
        self._ai_worker = AiWorker(text)
        self._ai_worker.done.connect(self._on_ai_ok)
        self._ai_worker.failed.connect(self._on_ai_fail)
        self._ai_worker.start()
        show_toast("AI 整理中…")

    def _save_ai_silent(self):
        cfg = config.load()
        cfg["ai"] = {
            "base_url": self.ai_base.text().strip(),
            "api_key": self.ai_key.text().strip(),
            "model": self.ai_model.text().strip(),
        }
        config.save(cfg)

    def _on_ai_ok(self, content):
        self._ai_dlg = OcrResultDialog(content, title="✨ AI 整理结果（可编辑，已自动复制）")

    def _on_ai_fail(self, err):
        show_toast(f"AI 失败：{err}", ok=False)

    # ---------- 历史 / 同步 ----------
    def _open_history(self):
        self._history = HistoryWindow()
        self._history.show()
        self._history.raise_()

    def _choose_sync_dir(self):
        d = QFileDialog.getExistingDirectory(
            self, "选择同步目录（建议放网盘同步盘内，如 OneDrive/微云/坚果云）",
            config.data_root())
        if not d:
            return
        old_root = config.data_root()
        cfg = config.load()
        cfg["sync_dir"] = d
        config.save(cfg)
        new_root = config.data_root()
        moved = 0
        for sub in ("memos", "history", "imgs"):
            src_dir = os.path.join(old_root, sub)
            if not os.path.isdir(src_dir):
                continue
            for f in glob.glob(os.path.join(src_dir, "*")):
                dst_dir = os.path.join(new_root, sub)
                os.makedirs(dst_dir, exist_ok=True)
                dst = os.path.join(dst_dir, os.path.basename(f))
                if not os.path.exists(dst):
                    try:
                        shutil.copy2(f, dst)
                        moved += 1
                    except OSError:
                        pass
        self.refresh()
        show_toast(f"同步目录已设置，迁移 {moved} 个文件")

    # ---------- 快捷键 ----------
    def _apply_hotkeys(self):
        keys = {}
        for action, kse in self.kse.items():
            hk = seq_to_hotkey(kse.keySequence())
            if hk:
                keys[action] = hk
        share = {a: cb.isChecked() for a, cb in self.cb_share.items()}

        cfg = config.load()
        for action in config.ACTION_NAMES:
            keys.setdefault(action, cfg["hotkeys"].get(action, ""))

        seen, dup = {}, set()
        for a, k in keys.items():
            if k in seen:
                dup.add(k)
            seen[k] = a
        if dup:
            show_toast(f"设置失败：组合键重复 {', '.join(dup)}，请重试", ok=False)
            return

        conflicts = [
            f"{config.ACTION_NAMES[a]} {k}"
            for a, k in keys.items()
            if k and not share.get(a) and is_conflicted(k)
        ]
        if conflicts:
            show_toast(
                "设置失败：「" + "、".join(conflicts)
                + "」已被其他软件占用，可更换或勾选共用，请重试", ok=False)
            return

        cfg["hotkeys"] = keys
        cfg["share"] = share
        config.save(cfg)
        ok = self.on_applied(cfg) if self.on_applied else True
        if ok:
            show_toast("快捷键设置已生效 ✓")
        else:
            show_toast("快捷键注册失败，请重试", ok=False)

    # ---------- 拖动 ----------
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.hide()
