# -*- coding: utf-8 -*-
"""OCR 服务：懒加载 RapidOCR，后台线程执行"""
from PySide6.QtCore import QThread, Signal


class OcrWorker(QThread):
    """在后台线程跑 OCR，避免卡 UI"""
    finished_ok = Signal(str)   # 识别文本
    failed = Signal(str)        # 错误信息

    def __init__(self, image, parent=None):
        super().__init__(parent)
        self._image = image

    def run(self):
        try:
            text = ocr_image(self._image)
            self.finished_ok.emit(text)
        except Exception as e:  # noqa: BLE001
            self.failed.emit(str(e))


_engine = None


def _get_engine():
    global _engine
    if _engine is None:
        from rapidocr_onnxruntime import RapidOCR
        _engine = RapidOCR()
    return _engine


def ocr_image(image) -> str:
    """image: numpy 数组 / ndarray / PIL Image（RapidOCR 支持 ndarray）"""
    engine = _get_engine()
    result, _ = engine(image)
    if not result:
        return ""
    return "\n".join(str(line[1]) for line in result)
