# -*- coding: utf-8 -*-
"""备忘录窗口：富文本工具栏、自由调整大小、置顶、锁定(穿透+🔓徽章)、粘贴图片/链接
右键菜单：锁定 / 存档 / 删除 / 设置；悬浮高亮动效；SwiftUI 风格
"""
import os
import re
import time

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import (QFont, QImage, QPixmap, QPainter, QTextCharFormat,
                           QTextListFormat, QColor, QDesktopServices, QTextCursor,
                           QCursor)
from PySide6.QtWidgets import (
    QWidget, QTextEdit, QHBoxLayout, QVBoxLayout, QPushButton, QLabel,
    QSizeGrip, QComboBox, QToolButton, QMenu, QApplication, QScrollArea,
    QSizePolicy, QFrame,
)

import config
from winutils import set_click_through

ACCENT = "#6b5ce7"   # v12：参考设计稿主色（紫）

# 由 main.py 注入
open_island = None   # (anchor) 打开设置岛
open_memo = None     # (memo_id) 打开便签

ALL_MEMOS = []

THEMES = {
    "dark": dict(
        panel="rgba(28,28,30,255)",
        text="#f5f5f7", dim="#d1d1d6", hover="#ffffff",
        pill="rgba(255,255,255,22)", icon="#c9c4f0",
        btn="rgba(255,255,255,26)", tool="rgba(255,255,255,26)",
        tool_text="#f5f5f7", border="rgba(255,255,255,60)",
    ),
    "light": dict(
        panel="rgba(233,230,247,255)",     # 参考稿薰衣草底
        text="#1d1d1f", dim="#6e6e73", hover="#1d1d1f",
        pill="#ffffff", icon="#5b4bc4",     # 白色胶囊工具栏 + 深紫图标
        btn="#f2f2f7", tool="#f2f2f7",
        tool_text="#1d1d1f", border="rgba(0,0,0,28)",
    ),
}

TEXT_COLORS = ["#1d1d1f", "#ff3b30", "#007AFF", "#34c759", "#ff9500"]
HIGHLIGHT = "#ffd60a"

URL_RE = re.compile(r"(https?://[^\s<>\"）)】]+|www\.[^\s<>\"）)】]+\.[^\s<>\"）)】]+)")
IMG_SRC_RE = re.compile(r'src="file:///([^"]+)"')

MENU_QSS = f"""
    QMenu {{ background: rgba(250,250,252,250); color: #1d1d1f;
            border: 1px solid rgba(0,0,0,30); border-radius: 12px; padding: 5px; }}
    QMenu::item {{ padding: 6px 22px; border-radius: 8px; font-size: 12px; }}
    QMenu::item:selected {{ background: {ACCENT}; color: white; }}
    QMenu::separator {{ height: 1px; background: rgba(0,0,0,28); margin: 4px 10px; }}
"""


def apply_settings_to_all():
    cfg = config.load()
    for m in list(ALL_MEMOS):
        try:
            m.apply_settings(cfg)
        except RuntimeError:
            ALL_MEMOS.remove(m)


def memo_under_cursor():
    from PySide6.QtGui import QCursor
    pos = QCursor.pos()
    for m in ALL_MEMOS:
        if m.isVisible() and m.frameGeometry().contains(pos):
            return m
    return None


class ImageViewer(QWidget):
    """双击便签里的图片后弹出，按屏幕大小看清整张图。点一下或按 Esc 关闭。"""

    def __init__(self, pixmap: QPixmap):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFocusPolicy(Qt.StrongFocus)
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        avail = screen.availableGeometry()
        max_w = max(120, int(avail.width() * 0.9))
        max_h = max(120, int(avail.height() * 0.9))
        shown = pixmap
        if pixmap.width() > max_w or pixmap.height() > max_h:
            shown = pixmap.scaled(max_w, max_h, Qt.KeepAspectRatio,
                                   Qt.SmoothTransformation)
        self._pm = shown
        pad = 28
        self.resize(shown.width() + pad, shown.height() + pad)
        self.move(avail.center().x() - self.width() // 2,
                  avail.center().y() - self.height() // 2)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(20, 20, 22, 242))
        p.drawRoundedRect(self.rect(), 16, 16)
        x = (self.width() - self._pm.width()) // 2
        y = (self.height() - self._pm.height()) // 2
        p.drawPixmap(x, y, self._pm)
        p.end()

    def mousePressEvent(self, e):
        self.close()

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key_Escape, Qt.Key_Return, Qt.Key_Enter):
            self.close()

    def showEvent(self, e):
        super().showEvent(e)
        self.raise_()
        self.activateWindow()
        self.setFocus()


class MemoEditor(QTextEdit):
    """支持粘贴图片 / 链接（URL 自动变为可点击）"""

    def __init__(self, memo=None):
        super().__init__()
        self.memo = memo
        self.setUndoRedoEnabled(True)
        # 让锚点可点击（QTextEdit 无 openExternalLinks，用信号手动打开）
        self.setTextInteractionFlags(
            Qt.TextEditorInteraction | Qt.LinksAccessibleByMouse)

    def insertFromMimeData(self, mime):
        """v13：完全接管粘贴，不走 Qt 默认富文本导入（QTextHtmlParser 是
        硬崩溃嫌疑点）；任何异常落盘日志并降级为纯文本，绝不闪退"""
        try:
            if mime.hasImage():
                data = mime.imageData()
                if isinstance(data, QPixmap):
                    img = data.toImage()
                elif isinstance(data, QImage):
                    img = QImage(data)
                elif isinstance(data, bytes):
                    img = QImage.fromData(data)
                else:
                    img = QImage()
                if not img.isNull():
                    path = self._save_image(img)
                    vw = max(self.viewport().width() - 24, 80)
                    if img.width() > vw:
                        h = int(img.height() * vw / img.width())
                        self.insertHtml(
                            f'<img src="file:///{path}" width="{vw}" height="{h}"><br>')
                    else:
                        self.insertHtml(f'<img src="file:///{path}"><br>')
                    return
            if mime.hasText():
                text = mime.text().strip()
                if re.fullmatch(r"https?://\S+|www\.\S+\.\S+", text):
                    url = text if text.startswith("http") else "http://" + text
                    self.insertHtml(
                        f'<a href="{url}" style="color:{ACCENT};">{text}</a>&nbsp;')
                    return
                # 富文本粘贴统一降级为纯文本（防 Qt HTML 导入路径的硬崩溃）
                self.insertPlainText(text)
                return
            super().insertFromMimeData(mime)
        except Exception as e:  # noqa: BLE001
            self._log_paste_error(e)
            try:
                if mime.hasText():
                    self.insertPlainText(mime.text())
            except Exception:  # noqa: BLE001
                pass

    @staticmethod
    def _log_paste_error(e):
        try:
            import time as _t
            import traceback as _tb
            import config as _cfg
            import os as _os
            with open(_os.path.join(_cfg.DATA_DIR, "error.log"), "a",
                      encoding="utf-8") as f:
                f.write(f"\n===== paste {_t.strftime('%Y-%m-%d %H:%M:%S')} =====\n")
                f.write("".join(_tb.format_exception(type(e), e, e.__traceback__)))
        except Exception:  # noqa: BLE001
            pass

    def mousePressEvent(self, e):
        self._anchor = self.anchorAt(e.position().toPoint())
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e):
        url = self.anchorAt(e.position().toPoint())
        if self._anchor and url and url == self._anchor:
            QDesktopServices.openUrl(QUrl(url))
            self._anchor = None
            return
        self._anchor = None
        super().mouseReleaseEvent(e)

    def mouseDoubleClickEvent(self, e):
        src = self._image_src_at(e.position().toPoint())
        if src and self._open_image(src):
            return
        super().mouseDoubleClickEvent(e)

    def _image_src_at(self, pos) -> str:
        cursor = self.cursorForPosition(pos)
        for delta in (0, -1, 1):
            p = cursor.position() + delta
            if p < 0 or p > self.document().characterCount():
                continue
            probe = QTextCursor(self.document())
            probe.setPosition(p)
            if not probe.movePosition(QTextCursor.NextCharacter, QTextCursor.KeepAnchor):
                continue
            fmt = probe.charFormat()
            if fmt.isImageFormat():
                return fmt.toImageFormat().name() or ""
        return ""

    def _open_image(self, src: str) -> bool:
        url = QUrl(src)
        path = url.toLocalFile() if url.isLocalFile() else src
        path = os.path.normpath(path) if path else ""
        pm = QPixmap(path) if path else QPixmap()
        if pm.isNull() and src:
            # Qt 有时只留下 file:/// 字符串，再解一次
            alt = QUrl.fromUserInput(src).toLocalFile()
            pm = QPixmap(os.path.normpath(alt)) if alt else QPixmap()
        if pm.isNull():
            from toast import show_toast
            show_toast("这张图片在本地找不到了", ok=False)
            return True
        self._viewer = ImageViewer(pm)
        self._viewer.show()
        return True

    @staticmethod
    def _save_image(img: QImage) -> str:
        d = config.imgs_dir()
        path = os.path.join(d, f"img_{time.time_ns()}.png").replace("\\", "/")
        img.save(path, "PNG")
        return path


class ToggleSwitch(QWidget):
    """v12：参考设计稿的 iOS 式锁定开关（紫底白钮）"""

    toggled = Signal(bool)

    def __init__(self, checked=False):
        super().__init__()
        self._on = checked
        self.setFixedSize(42, 24)
        self.setCursor(Qt.PointingHandCursor)

    def isChecked(self):
        return self._on

    def setChecked(self, on: bool):
        if self._on != on:
            self._on = on
            self.update()
            self.toggled.emit(on)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.setChecked(not self._on)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(ACCENT) if self._on else QColor("#c7c7cc"))
        p.drawRoundedRect(0, 0, 42, 24, 12, 12)
        p.setBrush(QColor("white"))
        p.drawEllipse(22 if self._on else 3, 3, 18, 18)
        p.end()


class MemoToolbar(QWidget):
    """富文本工具栏：撤销/重做 / 字号 / 加粗 / 文字颜色 / 高亮 / 分点 / 清除格式
    v12：参考设计稿——白色胶囊容器 + 深紫扁平图标；悬浮时紫描边凸显"""

    def __init__(self, editor: MemoEditor):
        super().__init__(editor)
        self.editor = editor
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._base_style = ""
        self._hover_style = ""
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        self.btn_undo = self._tool("↶", "撤销 Ctrl+Z", self.editor.undo)
        self.btn_redo = self._tool("↷", "重做 Ctrl+Y", self.editor.redo)
        lay.addWidget(self.btn_undo)
        lay.addWidget(self.btn_redo)

        # 字号
        self.size = QComboBox()
        self.size.addItems(["12", "14", "16", "18", "22", "28"])
        self.size.setCurrentIndex(1)
        self.size.setFixedWidth(56)
        self.size.currentTextChanged.connect(self._set_size)
        lay.addWidget(self.size)

        # 加粗
        self.btn_bold = self._tool("B", "加粗 Ctrl+B", self._toggle_bold,
                                   checkable=True)
        lay.addWidget(self.btn_bold)

        # 文字颜色（彩色圆点）
        self.color_btns = []
        for c in TEXT_COLORS:
            b = QToolButton()
            b.setFixedSize(18, 18)
            b.setToolTip(f"文字颜色 {c}")
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet(
                f"QToolButton{{border-radius:9px;background:{c};"
                f"border:1px solid rgba(0,0,0,45);}}"
                f"QToolButton:hover{{border:2px solid {ACCENT};}}")
            b.clicked.connect(lambda _=False, col=c: self._set_color(col))
            lay.addWidget(b)
            self.color_btns.append(b)

        # 高亮 / 分点 / 清除（文字按钮，避免符号显示异常）
        self.btn_hl = self._tool("高亮", "重点高亮", self._highlight)
        self.btn_list = self._tool("分点", "转为分点列表", self._bullet)
        self.btn_clear = self._tool("清除", "清除格式", self._clear_fmt)
        lay.addWidget(self.btn_hl)
        lay.addWidget(self.btn_list)
        lay.addWidget(self.btn_clear)

        lay.addStretch()

    def _tool(self, text, tip, slot, checkable=False):
        b = QToolButton()
        b.setText(text)
        b.setToolTip(tip)
        b.setCheckable(checkable)
        b.setCursor(Qt.PointingHandCursor)
        b.setMinimumHeight(24)
        b.clicked.connect(slot)
        return b

    def enterEvent(self, e):
        """悬浮富文本工具栏 → 紫描边凸显"""
        self.setStyleSheet(self._hover_style or self._base_style)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.setStyleSheet(self._base_style)
        super().leaveEvent(e)

    def apply_theme(self, t):
        """v12：白色胶囊容器 + 深紫扁平图标（参考设计稿）"""
        self._base_style = (f"background:{t['pill']};border-radius:16px;"
                            "border:1.5px solid transparent;")
        self._hover_style = (f"background:{t['pill']};border-radius:16px;"
                             f"border:1.5px solid {ACCENT};")
        self.setStyleSheet(self._base_style)
        icon = t["icon"]
        normal = (f"QToolButton {{ color: {icon}; background: transparent;"
                  f"border: none; border-radius: 8px;"
                  f"padding: 3px 8px; font-size: 12.5px; }}"
                  f"QToolButton:hover {{ background: {ACCENT}; color: white; }}")
        checked = (normal +
                   f"QToolButton:checked {{ background: {ACCENT}; color: white; }}")
        for b in (self.btn_undo, self.btn_redo, self.btn_hl,
                  self.btn_list, self.btn_clear):
            b.setStyleSheet(normal)
            b.setFixedHeight(28)
        self.btn_bold.setStyleSheet(checked)
        self.btn_bold.setFixedHeight(28)
        self.size.setStyleSheet(
            f"QComboBox {{ color: {icon}; background: transparent; border: none;"
            f"border-radius: 8px; padding: 2px 6px; font-size: 12.5px; }}"
            f"QComboBox:hover {{ background: {ACCENT}; color: white; }}"
            f"QComboBox QAbstractItemView {{ color: #1d1d1f; background: white;"
            f" border: 1px solid rgba(0,0,0,30); }}")
        self.size.setFixedHeight(28)

    # ---------- 动作 ----------
    def _apply(self, fmt: QTextCharFormat):
        cursor = self.editor.textCursor()
        if cursor.hasSelection():
            cursor.mergeCharFormat(fmt)
        self.editor.mergeCurrentCharFormat(fmt)

    def _set_size(self, text):
        fmt = QTextCharFormat()
        fmt.setFontPointSize(float(text))
        self._apply(fmt)

    def _toggle_bold(self):
        fmt = QTextCharFormat()
        fmt.setFontWeight(QFont.Bold if self.btn_bold.isChecked() else QFont.Normal)
        self._apply(fmt)

    def _set_color(self, col):
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(col))
        self._apply(fmt)

    def _highlight(self):
        fmt = QTextCharFormat()
        fmt.setBackground(QColor(HIGHLIGHT))
        self._apply(fmt)

    def _bullet(self):
        cursor = self.editor.textCursor()
        cursor.beginEditBlock()
        fmt = QTextListFormat()
        fmt.setStyle(QTextListFormat.ListDisc)
        fmt.setIndent(1)
        cursor.createList(fmt)
        cursor.endEditBlock()

    def _clear_fmt(self):
        cursor = self.editor.textCursor()
        fmt = QTextCharFormat()
        cursor.setCharFormat(fmt)
        self.editor.setCurrentCharFormat(fmt)


class UnlockBadge(QWidget):
    """锁定后唯一可点的开关（v15）
    便签锁定时整窗穿透点不到，此小窗只承载一个与标题栏完全相同的开关，
    且背景透明、尺寸一致、位置精确重合 → 用户看到的还是同一个开关，
    没有任何新增按钮或卡片。点击即解锁。"""

    def __init__(self, memo):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.memo = memo
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setCursor(Qt.PointingHandCursor)
        sw = ToggleSwitch(True)
        sw.setAttribute(Qt.WA_TransparentForMouseEvents)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(sw)
        self.adjustSize()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.memo.unlock()


class MemoWindow(QWidget):
    """单条便签。未锁定：右上角 🔒；锁定：本体穿透 + 右上角 🔓 徽章。
    无 ✕ 按钮，关闭/存档走右键菜单。"""

    def __init__(self, memo_id: str, text: str = "", parent=None):
        super().__init__(parent)
        self.memo_id = memo_id
        self.locked = False
        self._drag_pos = None
        self._archive_on_close = True
        self._hovered = False
        self._linking = False
        self.theme = THEMES["dark"]
        cfg = config.load()

        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setMinimumSize(220, 140)
        self.resize(340, 320)

        # v9：面板用 QFrame + 类选择器内联样式（objectName 选择器打包后不可靠）
        self.panel = QFrame()
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self.panel)

        lay = QVBoxLayout(self.panel)
        lay.setContentsMargins(12, 8, 12, 12)
        lay.setSpacing(4)

        # 标题栏：☰ / 标题 / 保存 / 锁定+开关 / ⋮（v12 参考设计稿）
        bar = QHBoxLayout()
        self.btn_menu = QPushButton("☰")
        self.title = QLabel("便签")
        self.btn_save = QPushButton("保存")
        self.btn_save.setToolTip("保存到本机 backup，并同步到设置里的飞书文档")
        self.lbl_lock = QLabel("锁定")
        self.switch = ToggleSwitch()
        self.switch.setToolTip("锁定后鼠标穿透；右侧浮出 🔓 徽章可解锁")
        self.btn_more = QPushButton("⋮")
        self.btn_more.setToolTip("更多操作（同右键菜单）")
        bar.addWidget(self.btn_menu)
        bar.addWidget(self.title)
        bar.addStretch()
        bar.addWidget(self.btn_save)
        bar.addWidget(self.lbl_lock)
        bar.addWidget(self.switch)
        bar.addWidget(self.btn_more)
        lay.addLayout(bar)

        # 富文本工具栏：横向滚动区（窗口窄时不挤压、不重叠）
        self.editor = MemoEditor(self)
        self.toolbar = MemoToolbar(self.editor)
        self.tool_scroll = QScrollArea()
        self.tool_scroll.setWidget(self.toolbar)
        self.tool_scroll.setWidgetResizable(True)
        self.tool_scroll.setFixedHeight(38)
        self.tool_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.tool_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tool_scroll.setFrameShape(QScrollArea.NoFrame)
        self.editor.setPlaceholderText(
            "输入备忘内容…支持 Ctrl+V 粘贴图片/链接\n"
            "双击图片可放大查看 · Ctrl+Z 撤销 · 右键更多操作")
        self._load_text(text)

        lay.addWidget(self.tool_scroll)
        lay.addWidget(self.editor, 1)

        self.grip = QSizeGrip(self)
        self.grip.setFixedSize(16, 16)
        self.grip.setStyleSheet("QSizeGrip{background:transparent;}")
        self.grip.setVisible(False)  # 悬浮时显示

        self.setFont(QFont("Microsoft YaHei UI", 10))
        self.badge = UnlockBadge(self)

        self.btn_menu.clicked.connect(lambda: self._open_island(self))
        self.btn_save.clicked.connect(self._on_save_clicked)
        self.switch.toggled.connect(
            lambda on: self.lock() if on else self.unlock())
        self.btn_more.clicked.connect(self._open_more_menu)
        self.editor.textChanged.connect(self._on_changed)

        self._link_timer = QTimer(self)
        self._link_timer.setSingleShot(True)
        self._link_timer.setInterval(400)
        self._link_timer.timeout.connect(self._linkify)

        ALL_MEMOS.append(self)
        self.apply_settings(cfg)
        self.show()

    # ---------- 设置岛 ----------
    @staticmethod
    def _open_island(anchor):
        if open_island:
            open_island(anchor)

    # ---------- 主题 / 悬浮态 ----------
    def apply_settings(self, cfg):
        self.theme = THEMES[cfg["theme"]]
        self.setWindowOpacity(cfg["opacity"] / 100)
        self._apply_style()
        self.toolbar.apply_theme(self.theme)

    def _apply_style(self):
        """v9：全部逐控件内联样式（打包 exe 下 objectName 选择器不可靠）
        v10：剔除悬浮蓝描边（用户反馈难看），凸显动效改为富文本工具栏悬浮"""
        t = self.theme
        self.panel.setStyleSheet(
            f"QFrame {{ background: {t['panel']}; border-radius: 18px;"
            f" border: 1px solid rgba(0,0,0,14); }}")
        self.title.setStyleSheet(
            f"QLabel {{ color: {t['text']}; font-size: 13px; font-weight: 600;"
            f" background: transparent; }}")
        self.lbl_lock.setStyleSheet(
            f"QLabel {{ color: {t['dim']}; font-size: 12px;"
            f" background: transparent; }}")
        self.editor.setStyleSheet(
            f"QTextEdit {{ background: transparent; color: {t['text']};"
            f" border: none; font-size: 14px;"
            f" selection-background-color: {ACCENT}; }}")
        btn_style = (
            f"QPushButton {{ color: {t['dim']}; background: transparent;"
            f" border: none; font-size: 14px; padding: 2px 8px;"
            f" border-radius: 8px; }}"
            f"QPushButton:hover {{ color: white; background: {ACCENT}; }}")
        self.btn_menu.setStyleSheet(btn_style)
        self.btn_more.setStyleSheet(btn_style)
        # v16：「保存」是文字按钮，用胶囊底 + 图标色，悬浮变紫
        self.btn_save.setStyleSheet(
            f"QPushButton {{ color: {t['icon']}; background: {t['pill']};"
            f" border: none; border-radius: 8px; font-size: 11.5px;"
            f" font-weight: 600; padding: 2px 9px; }}"
            f"QPushButton:hover {{ background: {ACCENT}; color: white; }}"
            f"QPushButton:pressed {{ background: #5848c9; color: white; }}")
        self.tool_scroll.setStyleSheet(
            "QScrollArea { background: transparent; border: none; }"
            "QScrollBar:horizontal { background: transparent; height: 6px; }"
            f"QScrollBar::handle:horizontal {{ background: {t['border']};"
            " border-radius: 3px; min-width: 26px; }"
            f"QScrollBar::handle:horizontal:hover {{ background: {ACCENT}; }}"
            "QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal"
            " { width: 0; height: 0; }")

    def enterEvent(self, e):
        self._hovered = True
        self.grip.setVisible(True)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hovered = False
        self.grip.setVisible(False)
        super().leaveEvent(e)

    # ---------- 右键菜单（⋮ 按钮同菜单） ----------
    def _open_more_menu(self):
        self._exec_menu(self.btn_more.mapToGlobal(
            self.btn_more.rect().bottomLeft()))

    def contextMenuEvent(self, e):
        self._exec_menu(e.globalPos())

    def _exec_menu(self, global_pos):
        menu = QMenu(self)
        menu.setStyleSheet(MENU_QSS)
        a_lock = menu.addAction("🔓 解锁便签" if self.locked else "🔒 锁定便签")
        menu.addSeparator()
        a_archive = menu.addAction("📥 存档到历史")
        a_delete = menu.addAction("🗑 删除此便签（不存档）")
        menu.addSeparator()
        a_setting = menu.addAction("⚙ 打开设置")
        act = menu.exec(global_pos)
        if act == a_lock:
            self.toggle_lock()
        elif act == a_archive:
            self.archive()
            self._archive_on_close = False
            self.close()
        elif act == a_delete:
            try:
                os.remove(config.memo_file(self.memo_id, "html"))
            except OSError:
                pass
            self._archive_on_close = False
            self.close()
        elif act == a_setting:
            self._open_island(self)

    # ---------- 锁定 ----------
    def lock(self):
        self.locked = True
        self._apply_lock()

    def unlock(self):
        self.locked = False
        self._apply_lock()
        self.raise_()
        self.activateWindow()
        self.editor.setFocus()

    def toggle_lock(self):
        self.unlock() if self.locked else self.lock()

    def _apply_lock(self):
        self.editor.setReadOnly(self.locked)
        self.toolbar.setVisible(not self.locked)
        self.switch.blockSignals(True)
        self.switch.setChecked(self.locked)
        self.switch.blockSignals(False)
        if not self.locked:
            self.editor.setFocus()
        QTimer.singleShot(0, self._apply_click_through)

    def _apply_click_through(self):
        set_click_through(int(self.winId()), self.locked)
        self._sync_badge()

    def _sync_badge(self):
        """v15：开关小窗精确贴在标题栏开关原位（像素级重合，视觉上就是同一个开关）"""
        if self.locked and self.isVisible():
            gp = self.switch.mapToGlobal(self.switch.rect().topLeft())
            bw, bh = self.badge.width(), self.badge.height()
            x, y = gp.x(), gp.y()
            try:
                scr = self.screen().availableGeometry()
                x = min(max(x, scr.left() + 2), max(scr.right() - bw - 2, scr.left() + 2))
                y = min(max(y, scr.top() + 2), max(scr.bottom() - bh - 2, scr.top() + 2))
            except Exception:
                pass
            self.badge.move(x, y)
            self.badge.show()
            self.badge.raise_()
        else:
            self.badge.hide()

    # ---------- 键盘（撤销/重做等） ----------
    def keyPressEvent(self, e):
        if not self.locked and (e.modifiers() & Qt.ControlModifier):
            if not self.editor.hasFocus():
                self.editor.setFocus()
            QApplication.sendEvent(self.editor, e)
            return
        super().keyPressEvent(e)

    # ---------- 拖动 / 大小 ----------
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag_pos = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            if not self.locked:
                self.editor.setFocus()  # 保证 Ctrl+Z 可用
            e.accept()

    def mouseMoveEvent(self, e):
        if self._drag_pos is not None:
            self.move(e.globalPosition().toPoint() - self._drag_pos)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._drag_pos = None
        self._save()

    def moveEvent(self, e):
        super().moveEvent(e)
        self._sync_badge()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.grip.move(self.width() - 18, self.height() - 18)
        self._sync_badge()

    # ---------- 持久化 / 链接 ----------
    def _on_changed(self):
        self._save()
        self._link_timer.start()

    def _load_text(self, text):
        html_path = config.memo_file(self.memo_id, "html")
        if os.path.exists(html_path):
            with open(html_path, encoding="utf-8") as f:
                self.editor.setHtml(f.read())
        else:
            txt = config.memo_file(self.memo_id, "txt")
            if os.path.exists(txt):
                with open(txt, encoding="utf-8") as f:
                    self.editor.setPlainText(f.read())
            else:
                self.editor.setPlainText(text)

    def _linkify(self):
        """正文里的网址自动变成可点击链接"""
        if self._linking:
            return
        self._linking = True
        try:
            doc = self.editor.document()
            text = self.editor.toPlainText()
            for m in URL_RE.finditer(text):
                url = m.group(0)
                href = url if url.startswith("http") else "http://" + url
                cur = doc.find(url)
                guard = 0
                while not cur.isNull() and guard < 20:
                    guard += 1
                    if not cur.charFormat().isAnchor():
                        fmt = QTextCharFormat()
                        fmt.setAnchor(True)
                        fmt.setAnchorHref(href)
                        fmt.setForeground(QColor(ACCENT))
                        fmt.setFontUnderline(True)
                        cur.mergeCharFormat(fmt)
                    cur = doc.find(url, cur)
        finally:
            self._linking = False

    def _save(self):
        try:
            with open(config.memo_file(self.memo_id, "html"), "w",
                      encoding="utf-8") as f:
                f.write(self.editor.toHtml())
        except OSError:
            pass

    # ---------- v16：保存到本地 backup ----------
    def _backup_html(self):
        """生成自包含 HTML（图片全部转 base64 内嵌）。返回 (html, 图片数)"""
        import base64
        html = self.editor.toHtml()
        n_img = 0

        def _inline(m):
            nonlocal n_img
            p = m.group(1).replace("/", os.sep)
            try:
                with open(p, "rb") as fh:
                    raw = fh.read()
            except OSError:
                return m.group(0)          # 图片丢了就保留原引用
            ext = os.path.splitext(p)[1].lower().lstrip(".") or "png"
            if ext == "jpg":
                ext = "jpeg"
            n_img += 1
            b64 = base64.b64encode(raw).decode("ascii")
            return f'src="data:image/{ext};base64,{b64}"'

        return IMG_SRC_RE.sub(_inline, html), n_img

    def _on_save_clicked(self):
        """「保存」按钮：按设置岛「保存方式」的勾选执行本地保存和/或飞书同步。"""
        from toast import show_toast
        mode = config.load().get("save_to") or {}
        to_local, to_fs = mode.get("local", True), mode.get("feishu", True)
        if not (to_local or to_fs):
            show_toast("没有勾选保存方式：请在设置岛「保存方式」里勾选", ok=False)
            return
        if to_local:
            name = self._save_local()
            if name is None:
                return
            if to_fs:
                show_toast(f"已保存到本地 {name}，正在同步飞书…")
                self._sync_feishu()
            else:
                show_toast(f"已保存到本地 {name}")
        else:
            show_toast("正在同步飞书…")
            self._sync_feishu()

    def _save_local(self):
        """把整条便签（文字 + 图片）导出到本地保存位置。返回提示用的文件名，失败返回 None。
        同一便签重复保存直接覆盖最新一份（v17.3 起不再弹窗询问），
        文件名以便签 ID 前 8 位开头用于识别同一条便签。"""
        from toast import show_toast
        try:
            d = config.backup_dir()
        except OSError as e:
            show_toast(f"保存失败：无法创建保存目录（{e}）", ok=False)
            return None
        try:
            html, n_img = self._backup_html()
        except Exception as e:  # noqa: BLE001
            show_toast(f"保存失败：{e}", ok=False)
            return None

        first = (self.editor.toPlainText().strip().split("\n")[0] or "")[:18]
        first = re.sub(r'[\\/:*?"<>|\s]+', "", first) or "便签"
        stamp = time.strftime("%Y%m%d_%H%M%S")
        memo8 = "".join(ch for ch in self.memo_id[:8] if ch.isalnum()) or "memo"
        new_path = os.path.join(d, f"{memo8}_{stamp}_{first}.html")

        import glob
        existing = sorted(glob.glob(os.path.join(d, f"{memo8}_*.html")),
                          key=os.path.getmtime)
        path = existing[-1] if existing else new_path   # 同一条便签覆盖最新一份，不再询问

        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(html)
        except OSError as e:
            show_toast(f"保存失败：{e}", ok=False)
            return None
        extra = f"（含 {n_img} 张图片）" if n_img else ""
        return os.path.basename(path) + extra

    def _note_segments(self):
        """按阅读顺序抽出文字和图片，供飞书同步使用。"""
        segs = []
        block = self.editor.document().begin()
        while block.isValid():
            buf = []
            it = block.begin()
            while not it.atEnd():
                frag = it.fragment()
                fmt = frag.charFormat() if frag.isValid() else None
                if fmt is not None and fmt.isImageFormat():
                    if buf:
                        segs.append({"type": "text", "text": "".join(buf)})
                        buf = []
                    segs.append({
                        "type": "image",
                        "path": fmt.toImageFormat().name() or "",
                    })
                elif frag.isValid():
                    buf.append(frag.text())
                it += 1
            if buf:
                segs.append({"type": "text", "text": "".join(buf)})
            segs.append({"type": "break"})
            block = block.next()
        return segs

    def _sync_feishu(self):
        from feishu_sync import FeishuSyncWorker
        from toast import show_toast
        if getattr(self, "_feishu_worker", None) is not None and self._feishu_worker.isRunning():
            self._feishu_pending = self._note_segments()
            return
        worker = FeishuSyncWorker(self._note_segments(), self)
        worker.done.connect(self._on_feishu_ok)
        worker.failed.connect(self._on_feishu_fail)
        worker.finished.connect(self._on_feishu_finished)
        self._feishu_worker = worker
        self._feishu_pending = None
        worker.start()

    def _on_feishu_ok(self, msg):
        from toast import show_toast
        if msg.startswith("http"):
            show_toast("已同步到飞书文档")
        else:
            show_toast(msg, ok=False)

    def _on_feishu_fail(self, err):
        from toast import show_toast
        show_toast(f"飞书同步失败：{err}", ok=False)

    def _on_feishu_finished(self):
        pending = getattr(self, "_feishu_pending", None)
        self._feishu_pending = None
        if pending:
            from feishu_sync import FeishuSyncWorker
            worker = FeishuSyncWorker(pending, self)
            worker.done.connect(self._on_feishu_ok)
            worker.failed.connect(self._on_feishu_fail)
            worker.finished.connect(self._on_feishu_finished)
            self._feishu_worker = worker
            worker.start()

    def archive(self):
        self._save()
        src = config.memo_file(self.memo_id, "html")
        if os.path.exists(src):
            import shutil
            shutil.move(src, config.memo_file(self.memo_id, "html", archived=True))

    def closeEvent(self, e):
        if self._archive_on_close:
            self.archive()
        else:
            self._save()
        if self in ALL_MEMOS:
            ALL_MEMOS.remove(self)
        self.badge.close()
        super().closeEvent(e)
