# -*- coding: utf-8 -*-
"""置顶截图窗（Pin 图）v9：
📷OCR（第一位+loading）/ 画笔 / 橡皮 / 文字（任意位置落点·可调字号颜色·拖拽缩放）
/ 清空（笔迹+文字）/ 复制（含笔迹文字）/ 图片边缘拉伸（纵横比锁定）/ 滚轮缩放
"""
import numpy as np
from PySide6.QtCore import Qt, QRectF, QPointF, QRect, QPoint, QTimer
from PySide6.QtGui import (QPixmap, QImage, QTransform, QColor, QFont,
                           QTextCursor, QPainter, QPen, QPainterPath)
from PySide6.QtWidgets import (
    QWidget, QGraphicsView, QGraphicsScene, QGraphicsPixmapItem,
    QGraphicsTextItem, QGraphicsPathItem, QMenu, QTextEdit, QPushButton,
    QVBoxLayout, QLabel, QHBoxLayout, QSizePolicy, QToolButton, QProgressBar,
)

from winutils import set_click_through
from ocr_service import OcrWorker
import config

ALL_PINS = []

ACCENT = "#007AFF"

PIN_THEMES = {
    "dark": "rgba(28,28,30,255)",
    "light": "rgba(255,255,255,255)",
}

PEN_COLORS = ["#ff3b30", "#ff9500", "#ffd60a", "#34c759", "#007AFF", "#ffffff", "#1d1d1f"]
PEN_WIDTHS = [("细", 3), ("中", 6), ("粗", 12)]

TOOLBAR_H = 42   # 顶部预留给编辑栏（编辑栏贴图片正上方）


def apply_settings_to_pins():
    cfg = config.load()
    for w in list(ALL_PINS):
        try:
            w.apply_settings(cfg)
        except RuntimeError:
            ALL_PINS.remove(w)


def pixmap_to_ndarray(pix: QPixmap):
    img = pix.toImage().convertToFormat(QImage.Format_BGR888)
    h, w = img.height(), img.width()
    buf = np.frombuffer(img.constBits(), dtype=np.uint8, count=img.sizeInBytes())
    arr = buf.reshape(h, img.bytesPerLine())[:, : w * 3].reshape(h, w, 3)
    return np.ascontiguousarray(arr)


MENU_QSS = f"""
    QMenu {{ background: rgba(250,250,252,248); color: #1d1d1f;
            border: 1px solid rgba(0,0,0,30); border-radius: 12px; padding: 5px; }}
    QMenu::item {{ padding: 6px 22px; border-radius: 8px; font-size: 12px; }}
    QMenu::item:selected {{ background: {ACCENT}; color: white; }}
    QMenu::separator {{ height: 1px; background: rgba(0,0,0,28);
                        margin: 4px 10px; }}
"""


class OcrResultDialog(QWidget):
    """OCR 结果：置顶小窗，可编辑，一键复制（SwiftUI 卡片风格）"""

    def __init__(self, text: str, title: str = "识别结果（可编辑，已自动复制）"):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.resize(400, 280)

        card = QWidget()
        card.setStyleSheet(
            "QWidget{background:rgba(250,250,252,250);border-radius:16px;"
            "border:1px solid rgba(0,0,0,26);}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(card)
        v = QVBoxLayout(card)
        v.setContentsMargins(14, 12, 14, 14)
        head = QHBoxLayout()
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet(
            "QLabel{color:#3a3a3c;font-size:11px;background:transparent;}")
        btn_copy = QPushButton("复制")
        btn_close = QPushButton("✕")
        for b in (btn_copy, btn_close):
            b.setStyleSheet(
                "QPushButton{background:#e5e5ea;color:#1d1d1f;border:none;"
                "border-radius:13px;padding:6px 14px;font-size:12px;}"
                "QPushButton:hover{background:#dcdce2;}")
        head.addWidget(title_lbl)
        head.addStretch()
        head.addWidget(btn_copy)
        head.addWidget(btn_close)
        v.addLayout(head)

        self.editor = QTextEdit()
        self.editor.setStyleSheet(
            "QTextEdit{background:rgba(255,255,255,220);color:#1d1d1f;"
            "border:1px solid rgba(0,0,0,24);border-radius:10px;"
            "padding:8px;font-size:13px;}")
        self.editor.setPlainText(text)
        v.addWidget(self.editor, 1)

        btn_copy.clicked.connect(self._copy)
        btn_close.clicked.connect(self.close)
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(text)

        self._drag = None
        self.show()
        self.activateWindow()

    def _copy(self):
        from PySide6.QtWidgets import QApplication
        QApplication.clipboard().setText(self.editor.toPlainText())

    def mousePressEvent(self, e):
        self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.close()


# ---------- 编辑栏按钮内联样式（打包 exe 下不依赖选择器） ----------
TB_BTN_STYLE = (
    "QToolButton{background:rgba(255,255,255,26);color:#f5f5f7;"
    "border:none;border-radius:13px;font-size:13px;padding:2px 6px;}"
    "QToolButton:hover{background:rgba(255,255,255,56);color:white;}"
    "QToolButton:disabled{color:rgba(255,255,255,100);"
    "background:rgba(255,255,255,14);}"
    "QToolButton:checked{background:#007AFF;color:white;}")


class PinToolbar(QWidget):
    """编辑栏：📷OCR / 画笔 / 彩点 / 粗细 / 橡皮 / 文字 / A- A+ / 清空
    v10：鼠标悬浮时整条凸显"""

    _BASE_STYLE = ("background:rgba(28,28,30,235);border-radius:17px;"
                   "border:1px solid rgba(255,255,255,30);")
    _HOVER_STYLE = ("background:rgba(44,44,46,248);border-radius:17px;"
                    "border:2px solid rgba(0,122,255,210);")

    def enterEvent(self, e):
        self.setStyleSheet(self._HOVER_STYLE)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.setStyleSheet(self._BASE_STYLE)
        super().leaveEvent(e)

    def __init__(self, win: "PinWindow"):
        super().__init__(win)
        self.win = win
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setStyleSheet(self._BASE_STYLE)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(6, 3, 6, 3)
        lay.setSpacing(2)

        # ① OCR（第一位，相机图标）
        self.btn_ocr = self._mk("📷", 36, "OCR 识别图中文字（识别中请稍候）",
                                on_click=win.run_ocr)
        lay.addWidget(self.btn_ocr)

        # ② 画笔
        self.btn_pen = self._mk("画笔", 44, "画笔（点亮后可在截图上画）",
                                checkable=True, on_click=lambda: self._mode("pen"))
        lay.addWidget(self.btn_pen)

        # ③ 彩色圆点（选中加白圈；选中文字时改文字颜色）
        self.color_btns = {}
        for c in PEN_COLORS:
            b = QToolButton()
            b.setCheckable(True)
            b.setFixedSize(18, 18)
            b.setCursor(Qt.PointingHandCursor)
            b.setToolTip(f"颜色 {c}（选中文字时改文字颜色，否则改画笔）")
            b.clicked.connect(lambda _=False, col=c: self._pick_color(col))
            lay.addWidget(b)
            self.color_btns[c] = b
        self._sync_color_ring()

        # ④ 粗细
        self.width_btns = []
        for i, (name, w) in enumerate(PEN_WIDTHS):
            b = self._mk(name, 28, f"笔宽 {w}px", checkable=True,
                         on_click=lambda _=False, idx=i: self._pick_width(idx))
            lay.addWidget(b)
            self.width_btns.append(b)
        self._sync_width()

        # ⑤ 橡皮
        self.btn_eraser = self._mk("橡皮", 40, "擦除笔迹",
                                   checkable=True, on_click=lambda: self._mode("eraser"))
        lay.addWidget(self.btn_eraser)

        # ⑥ 文字（点击后在图片任意位置单击落点）
        self.btn_text = self._mk("文字", 40,
                                 "点我后在图片任意位置单击加文字；点已加的文字可再编辑；再点我退出",
                                 checkable=True, on_click=self._toggle_text)
        lay.addWidget(self.btn_text)

        # ⑦ 字号 A- / A+（选中文字时调其字号，否则调默认字号）
        self.btn_a_minus = self._mk("A−", 30, "字号减小（选中文字后生效）",
                                    on_click=lambda: self.win.adjust_text_size(-2))
        self.btn_a_plus = self._mk("A＋", 30, "字号增大（选中文字后生效）",
                                   on_click=lambda: self.win.adjust_text_size(2))
        lay.addWidget(self.btn_a_minus)
        lay.addWidget(self.btn_a_plus)

        # ⑧ 清空（笔迹 + 文字）
        self.btn_clear = self._mk("清空", 40, "清除全部笔迹和文字标注",
                                  on_click=win.clear_drawings)
        lay.addWidget(self.btn_clear)

        # OCR loading 动画计时器
        self._ocr_timer = QTimer(self)
        self._ocr_timer.setInterval(300)
        self._ocr_timer.timeout.connect(self._tick_ocr)
        self._ocr_dots = 0

    def _mk(self, text, w, tip, checkable=False, on_click=None):
        b = QToolButton()
        b.setText(text)
        b.setToolTip(tip)
        b.setCheckable(checkable)
        b.setFixedSize(w, 26)
        b.setStyleSheet(TB_BTN_STYLE)
        if on_click:
            b.clicked.connect(on_click)
        return b

    # ---------- OCR loading ----------
    def set_ocr_loading(self, on: bool):
        self.btn_ocr.setEnabled(not on)
        if on:
            self._ocr_dots = 0
            self.btn_ocr.setText("⏳")
            self._ocr_timer.start()
        else:
            self._ocr_timer.stop()
            self.btn_ocr.setText("📷")

    def _tick_ocr(self):
        self._ocr_dots = (self._ocr_dots + 1) % 4
        self.btn_ocr.setText("识别中" + "·" * self._ocr_dots)

    # ---------- 模式 ----------
    def _sync_color_ring(self):
        for c, b in self.color_btns.items():
            on = c == self.win.pen_color.name()
            border = "2px solid white" if on else "1px solid rgba(255,255,255,60)"
            b.setStyleSheet(
                f"QToolButton{{border-radius:9px;background:{c};border:{border};}}"
                f"QToolButton:hover{{border:2px solid white;}}")
            b.setChecked(on)

    def _sync_width(self):
        for i, b in enumerate(self.width_btns):
            b.setChecked(PEN_WIDTHS[i][1] == self.win.pen_width)

    def sync_mode_buttons(self):
        """窗口 Esc 退出模式后同步按钮选中态"""
        self.btn_pen.setChecked(self.win.draw_mode == "pen")
        self.btn_eraser.setChecked(self.win.draw_mode == "eraser")
        self.btn_text.setChecked(self.win.draw_mode == "text")

    def _mode(self, m):
        if m == "pen":
            erasing = self.btn_eraser.isChecked()
            self.btn_eraser.setChecked(False)
            self.btn_text.setChecked(False)
            if erasing:
                self.btn_pen.setChecked(True)
            self.win.draw_mode = "pen" if self.btn_pen.isChecked() else "none"
        else:
            on = self.btn_eraser.isChecked()
            self.btn_pen.setChecked(False)
            self.btn_text.setChecked(False)
            self.win.draw_mode = "eraser" if on else "none"
        self.win.view._update_cursor()

    def _toggle_text(self):
        on = self.btn_text.isChecked()
        self.btn_pen.setChecked(False)
        self.btn_eraser.setChecked(False)
        self.win.draw_mode = "text" if on else "none"
        self.win.view._update_cursor()

    def _pick_color(self, col):
        # 选中文字标注 → 改文字颜色；否则改画笔颜色并进入画笔模式
        if self.win.set_text_color(QColor(col)):
            return
        self.win.pen_color = QColor(col)
        self.win.draw_mode = "pen"
        self.btn_pen.setChecked(True)
        self.btn_eraser.setChecked(False)
        self.btn_text.setChecked(False)
        self._sync_color_ring()
        self.win.view._update_cursor()

    def _pick_width(self, idx):
        self.win.pen_width = PEN_WIDTHS[idx][1]
        self._sync_width()


class PinWindow(QWidget):
    """截图贴在桌面上：永久置顶、画笔、文字、图片边缘拉伸（锁定纵横比）、滚轮缩放"""

    def __init__(self, pixmap: QPixmap):
        super().__init__()
        self.pix = pixmap
        self._drag = None
        self._resize_mode = None
        self._resize_geom = None
        self._resize_origin = None
        self._ocr_running = False
        self.text_color = QColor("#ffd60a")
        self.text_font_size = 12      # 新文字标注默认字号
        self.draw_mode = "none"      # none / pen / eraser / text
        self.pen_color = QColor(PEN_COLORS[0])
        self.pen_width = PEN_WIDTHS[1][1]  # 默认「中」

        self.setWindowFlags(
            Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
        )
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.scene = QGraphicsScene(self)
        self.scene.setSceneRect(QRectF(0, 0, pixmap.width(), pixmap.height()))
        self.pixmap_item = QGraphicsPixmapItem(pixmap)
        self.scene.addItem(self.pixmap_item)

        self.view = PinGraphicsView(self)
        self.view.setParent(self)
        self.view.setScene(self.scene)
        # 不使用布局：隐藏期触发的 resizeEvent 中布局未激活，
        # fitInView 会拿到错误视口尺寸；改为事件里手动设几何（见 resizeEvent/showEvent）

        # 画笔编辑栏（贴图片正上方、居中）
        self.toolbar = PinToolbar(self)

        # OCR 进度条（识别时显示在编辑栏正下方）
        self.ocr_bar = QProgressBar(self)
        self.ocr_bar.setRange(0, 0)          # busy 指示
        self.ocr_bar.setTextVisible(False)
        self.ocr_bar.setFixedHeight(5)
        self.ocr_bar.setStyleSheet(
            "QProgressBar{background:rgba(255,255,255,30);border:none;"
            "border-radius:2px;}"
            "QProgressBar::chunk{background:#007AFF;border-radius:2px;}")
        self.ocr_bar.hide()

        self.setMinimumSize(120, TOOLBAR_H + 60)
        self.toolbar.adjustSize()
        # 初始宽度不小于编辑栏宽度（避免开窗即被钳制）
        self.resize(max(pixmap.width(), self.toolbar.width() + 16),
                    pixmap.height() + TOOLBAR_H)

        ALL_PINS.append(self)
        self.apply_settings(config.load())
        self.show()

    def apply_settings(self, cfg):
        # 逐控件内联样式：窗口背景 + 视图透明（打包 exe 下可靠）
        self.setStyleSheet(
            f"background:{PIN_THEMES[cfg['theme']]};border-radius:14px;")
        self.view.setStyleSheet("background:transparent;border:none;")
        self.setWindowOpacity(cfg["opacity"] / 100 if cfg.get("opacity", 100) < 100 else 1.0)

    def _refit(self):
        """视图铺满 TOOLBAR_H 以下的窗口区域，再等比缩放图片铺满
        （不用 fitInView：其自带 2px 边距会让图片与窗口边缘脱开）"""
        self.view.setGeometry(0, TOOLBAR_H, self.width(),
                              max(1, self.height() - TOOLBAR_H))
        vp = self.view.viewport()
        sr = self.scene.sceneRect()
        if vp.width() <= 0 or vp.height() <= 0 or sr.width() <= 0:
            return
        s = min(vp.width() / sr.width(), vp.height() / sr.height())
        self.view.setTransform(QTransform().scale(s, s))
        self.view.centerOn(sr.center())

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._refit()
        self._place_chrome()

    def showEvent(self, e):
        super().showEvent(e)
        self._refit()
        self._place_chrome()

    def _place_chrome(self):
        """编辑栏：紧贴图片正上方 + 水平居中；OCR 进度条贴编辑栏正下方"""
        self.toolbar.adjustSize()
        self.setMinimumWidth(max(120, self.toolbar.width() + 16))
        img = self._image_rect()
        x = img.x() + (img.width() - self.toolbar.width()) // 2
        x = min(max(x, 0), max(self.width() - self.toolbar.width(), 0))
        y = img.y() - self.toolbar.height() - 2
        if y < 2:
            y = 2
        self.toolbar.move(x, y)
        self.toolbar.raise_()
        bw = min(180, self.toolbar.width())
        self.ocr_bar.setFixedWidth(bw)
        self.ocr_bar.move(x + (self.toolbar.width() - bw) // 2,
                          y + self.toolbar.height() + 3)
        self.ocr_bar.raise_()

    def _image_rect(self):
        """图片在窗口中实际渲染的矩形（纵横比锁定时应与窗口内容区一致）"""
        mapped = self.view.mapFromScene(self.scene.sceneRect())
        if isinstance(mapped, QRect):
            r = QRect(mapped)
        else:  # QPolygonF
            r = mapped.boundingRect()
            if hasattr(r, "toRect"):
                r = r.toRect()
        r.translate(self.view.mapTo(self, QPoint(0, 0)))
        return r

    # ---------- 图片边缘拉伸：8 向 + 纵横比锁定 ----------
    EDGE = 8

    def _edge_at(self, p: QPoint):
        """返回命中方向（nw/n/ne/e/se/s/sw/w），未命中返回 None"""
        if self.toolbar.geometry().contains(p):
            return None  # 编辑栏区域不触发
        w, h = self.width(), self.height()
        left = p.x() <= self.EDGE
        right = p.x() >= w - self.EDGE - 1
        top = p.y() <= self.EDGE
        bottom = p.y() >= h - self.EDGE - 1
        if top and left:
            return "nw"
        if top and right:
            return "ne"
        if bottom and left:
            return "sw"
        if bottom and right:
            return "se"
        if top:
            return "n"
        if bottom:
            return "s"
        if left:
            return "w"
        if right:
            return "e"
        return None

    def _begin_resize(self, local: QPoint) -> bool:
        mode = self._edge_at(local)
        if not mode:
            return False
        from PySide6.QtGui import QCursor
        self._resize_mode = mode
        self._resize_geom = QRect(self.geometry())
        self._resize_origin = QCursor.pos()
        # 拖拽期间用快速变换，避免大图逐帧平滑重采样卡顿
        self.view.setRenderHints(QPainter.SmoothPixmapTransform, False)
        return True

    def _update_resize(self, global_pos):
        """按被拖拽侧缩放，并锁定图片纵横比 → 图片永远撑满窗口，边缘即图片边缘"""
        if not self._resize_mode:
            return
        dx = global_pos.x() - self._resize_origin.x()
        dy = global_pos.y() - self._resize_origin.y()
        g = QRect(self._resize_geom)
        m = self._resize_mode
        if "e" in m:
            g.setRight(g.right() + dx)
        if "s" in m:
            g.setBottom(g.bottom() + dy)
        if "w" in m:
            g.setLeft(g.left() + dx)
        if "n" in m:
            g.setTop(g.top() + dy)

        aspect = self.pix.width() / max(1, self.pix.height())
        cw, ch = g.width(), g.height() - TOOLBAR_H
        if m in ("n", "s"):          # 上下拖 → 高度驱动宽度
            ch = max(48, ch)
            cw = max(60, round(ch * aspect))
        else:                        # 左右/角拖 → 宽度驱动高度
            cw = max(60, cw)
            ch = max(48, round(cw / aspect))

        # 以被拖拽侧为锚点回写
        if "w" in m:
            g.setLeft(g.right() - cw)
        else:
            g.setRight(g.left() + cw - 1)
        if "n" in m:
            g.setTop(g.bottom() - (ch + TOOLBAR_H) + 1)
        else:
            g.setBottom(g.top() + ch + TOOLBAR_H - 1)
        self.setGeometry(g)

    def _end_resize(self):
        was = self._resize_mode
        self._resize_mode = None
        if was:
            self.view.setRenderHints(QPainter.SmoothPixmapTransform, True)
            self.view.viewport().update()

    @staticmethod
    def _cursor_for_edge(mode):
        return {
            "nw": Qt.SizeFDiagCursor, "se": Qt.SizeFDiagCursor,
            "ne": Qt.SizeBDiagCursor, "sw": Qt.SizeBDiagCursor,
            "n": Qt.SizeVerCursor, "s": Qt.SizeVerCursor,
            "e": Qt.SizeHorCursor, "w": Qt.SizeHorCursor,
        }.get(mode)

    # ---------- 画笔 ----------
    def begin_stroke(self, scene_pos: QPointF):
        path = QPainterPath()
        path.moveTo(scene_pos)
        item = QGraphicsPathItem()
        pen = QPen(self.pen_color, self.pen_width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
        item.setPen(pen)
        item.setPath(path)
        item.setData(1, "drawn")  # 标记为笔迹
        self.scene.addItem(item)
        return item

    def extend_stroke(self, item, scene_pos: QPointF):
        path = item.path()
        path.lineTo(scene_pos)
        item.setPath(path)

    def erase_at(self, scene_pos: QPointF):
        for it in self.scene.items(scene_pos):
            if it.data(1) == "drawn":
                self.scene.removeItem(it)
                return True
        return False

    def clear_drawings(self):
        """清空：笔迹 + 文字标注一起清除"""
        for it in list(self.scene.items()):
            if it.data(1) == "drawn" or isinstance(it, QGraphicsTextItem):
                self.scene.removeItem(it)

    # ---------- 文字标注 ----------
    def add_text_item(self, scene_pos, initial=""):
        item = QGraphicsTextItem(initial or "输入文字…")
        item.setDefaultTextColor(self.text_color)
        font = QFont("Microsoft YaHei UI", self.text_font_size)
        font.setBold(True)
        item.setFont(font)
        item.setTextInteractionFlags(Qt.TextEditorInteraction)
        item.setFlag(QGraphicsTextItem.ItemIsMovable, True)
        item.setFlag(QGraphicsTextItem.ItemIsSelectable, True)
        item.setPos(scene_pos)
        self.scene.addItem(item)
        item.setFocus()
        item.setSelected(True)
        cursor = QTextCursor(item.document())
        cursor.select(QTextCursor.Document)
        item.setTextCursor(cursor)
        return item

    def selected_text_items(self):
        return [it for it in self.scene.selectedItems()
                if isinstance(it, QGraphicsTextItem)]

    def adjust_text_size(self, delta: int):
        """A- / A+：有选中文字调其字号，否则调新文字默认字号"""
        items = self.selected_text_items()
        if items:
            for it in items:
                f = it.font()
                pt = max(8, min(72, f.pointSize() + delta))
                f.setPointSize(pt)
                it.setFont(f)
                it.setSelected(True)
        else:
            self.text_font_size = max(8, min(72, self.text_font_size + delta))

    def set_text_color(self, color: QColor) -> bool:
        """有选中文字时改其颜色，返回 True；否则返回 False（由调用方改画笔色）"""
        items = self.selected_text_items()
        if items:
            for it in items:
                it.setDefaultTextColor(color)
                it.setSelected(True)
            return True
        return False

    def scale_selected_text(self, factor: float):
        for it in self.selected_text_items():
            it.setScale(max(0.3, min(6.0, it.scale() * factor)))

    def all_annotation_text(self) -> str:
        texts = []
        for it in self.scene.items():
            if isinstance(it, QGraphicsTextItem):
                texts.append(it.toPlainText())
        return "\n".join(t for t in texts if t.strip())

    # ---------- 渲染（含笔迹和文字） ----------
    def _render_annotated(self) -> QImage:
        img = QImage(self.pix.width(), self.pix.height(),
                     QImage.Format_ARGB32_Premultiplied)
        img.fill(Qt.transparent)
        p = QPainter(img)
        self.scene.render(p, QRectF(0, 0, self.pix.width(), self.pix.height()),
                          QRectF(0, 0, self.pix.width(), self.pix.height()))
        p.end()
        return img

    # ---------- OCR ----------
    def run_ocr(self):
        if self._ocr_running:
            return
        self._ocr_running = True
        self.toolbar.set_ocr_loading(True)
        self.ocr_bar.show()
        self._place_chrome()
        arr = pixmap_to_ndarray(self.pix)
        self._ocr_worker = OcrWorker(arr)
        self._ocr_worker.finished_ok.connect(self._on_ocr_ok)
        self._ocr_worker.failed.connect(self._on_ocr_fail)
        self._ocr_worker.start()

    def _ocr_done(self):
        self._ocr_running = False
        self.toolbar.set_ocr_loading(False)
        self.ocr_bar.hide()

    def _on_ocr_ok(self, text):
        self._ocr_done()
        text = text.strip() or "（未识别到文字）"
        self._ocr_dlg = OcrResultDialog(text)

    def _on_ocr_fail(self, err):
        self._ocr_done()
        self._ocr_dlg = OcrResultDialog(f"OCR 失败：{err}")

    def zoom(self, factor: float):
        # 等比缩放窗口，纵横比不变 → 图片始终撑满
        self.resize(max(int(self.width() * factor), 120),
                    max(int(self.height() * factor), TOOLBAR_H + 60))

    # ---------- 菜单 ----------
    def contextMenuEvent(self, e):
        hit_text = None
        vp = self.view.mapFromGlobal(e.globalPos())
        sp = self.view.mapToScene(vp)
        for it in self.scene.items(sp):
            if isinstance(it, QGraphicsTextItem):
                hit_text = it
                break

        menu = QMenu(self)
        menu.setStyleSheet(MENU_QSS)
        a_del_text = None
        if hit_text is not None:
            a_del_text = menu.addAction("🗑 删除此文字标注")
            menu.addSeparator()
        a_ocr = menu.addAction("🔍 识别文字 (OCR 并复制)")
        menu.addSeparator()
        a_copy_all = menu.addAction("📋 复制图片（含笔迹和文字）")
        a_copy_raw = menu.addAction("📋 复制原图（不含标注）")
        a_copy_txt = menu.addAction("📋 复制全部标注文字")
        menu.addSeparator()

        op_menu = menu.addMenu("🌫 窗口透明度")
        op_menu.setStyleSheet(MENU_QSS)
        ops = {}
        for v in (100, 85, 70, 50):
            act = op_menu.addAction(f"{v}%")
            ops[act] = v

        a_reset = menu.addAction("↩ 重置大小")
        a_save_all = menu.addAction("💾 另存 PNG（含笔迹和文字）")
        a_save_raw = menu.addAction("💾 另存 PNG（原图）")
        menu.addSeparator()
        a_close = menu.addAction("✕ 关闭 (Del)")

        act = menu.exec(e.globalPos())
        if act is None:
            return
        if act == a_del_text and hit_text is not None:
            self.scene.removeItem(hit_text)
        elif act == a_ocr:
            self.run_ocr()
        elif act == a_copy_all:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setPixmap(
                QPixmap.fromImage(self._render_annotated()))
        elif act == a_copy_raw:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setPixmap(self.pix)
        elif act == a_copy_txt:
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(self.all_annotation_text())
        elif act in ops:
            self.setWindowOpacity(ops[act] / 100)
        elif act == a_reset:
            self.resize(self.pix.width(), self.pix.height() + TOOLBAR_H)
        elif act == a_save_all:
            self._save_png(annotated=True)
        elif act == a_save_raw:
            self._save_png(annotated=False)
        elif act == a_close:
            self.close()

    def _save_png(self, annotated=True):
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "保存截图", "pin.png", "PNG (*.png)")
        if not path:
            return
        if annotated:
            self._render_annotated().save(path)
        else:
            self.pix.save(path, "PNG")

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            if self.draw_mode != "none":
                # 先退出当前模式（画笔/橡皮/文字），再按才关闭
                self.draw_mode = "none"
                self.toolbar.sync_mode_buttons()
                self.view._update_cursor()
                return
            self.close()
        elif e.key() == Qt.Key_Delete:
            sel = self.selected_text_items()
            if sel:
                for it in sel:
                    self.scene.removeItem(it)
                return
            self.close()

    # ---------- 窗口拖动 ----------
    def start_drag(self, global_pos):
        self._drag = global_pos - self.frameGeometry().topLeft()

    def do_drag(self, global_pos):
        if self._drag is not None:
            self.move(global_pos - self._drag)

    def end_drag(self):
        self._drag = None


class PinGraphicsView(QGraphicsView):
    """拖动窗口 / 画笔 / 橡皮 / 文字落点 / 双击文字 / 滚轮缩放（选中文字→缩放文字）"""

    def __init__(self, win: PinWindow):
        super().__init__()
        self.win = win
        self._stroke = None
        self.setFrameShape(QGraphicsView.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setRenderHints(QPainter.SmoothPixmapTransform)

    def _update_cursor(self):
        if self.win.draw_mode == "pen":
            self.setCursor(Qt.CrossCursor)
        elif self.win.draw_mode == "eraser":
            self.setCursor(Qt.BlankCursor)
        elif self.win.draw_mode == "text":
            self.setCursor(Qt.IBeamCursor)
        else:
            self.setCursor(Qt.ArrowCursor)

    def _edge_cursor(self, e):
        """非绘制模式下，窗口（=图片）边缘显示拉伸光标（仅在变化时设置）"""
        if self.win.draw_mode != "none" or self.win._resize_mode:
            return
        p = self.mapTo(self.win, e.position().toPoint())
        cur = self.win._cursor_for_edge(self.win._edge_at(p))
        if cur is not None:
            if self.cursor().shape() != cur:
                self.setCursor(cur)
            self._on_edge = True
        elif getattr(self, "_on_edge", False):
            self.unsetCursor()
            self._on_edge = False

    def _hit_item(self, pos):
        return self.scene().itemAt(self.mapToScene(pos), QTransform())

    def mousePressEvent(self, e):
        p = e.position().toPoint()
        if e.button() == Qt.LeftButton:
            # 图片边缘 → 拉伸（优先于绘图与拖动）
            if self.win._begin_resize(self.mapTo(self.win, p)):
                return
            if self.win.draw_mode == "pen":
                self._stroke = self.win.begin_stroke(self.mapToScene(p))
                return
            if self.win.draw_mode == "eraser":
                self.win.erase_at(self.mapToScene(p))
                return
            if self.win.draw_mode == "text":
                item = self._hit_item(p)
                if isinstance(item, QGraphicsTextItem):
                    super().mousePressEvent(e)   # 点已有文字 → 选中/编辑
                    return
                # 图片任意空白位置 → 落一个新文字
                self.win.add_text_item(self.mapToScene(p))
                return
            item = self._hit_item(p)
            if item is None or item is self.win.pixmap_item:
                self.win.start_drag(e.globalPosition().toPoint())
                return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        p = e.position().toPoint()
        if self.win._resize_mode:
            self.win._update_resize(e.globalPosition().toPoint())
            return
        if self._stroke is not None:
            self.win.extend_stroke(self._stroke, self.mapToScene(p))
            return
        if self.win.draw_mode == "eraser" and e.buttons() & Qt.LeftButton:
            self.win.erase_at(self.mapToScene(p))
            return
        if self.win._drag is not None:
            self.win.do_drag(e.globalPosition().toPoint())
            return
        self._edge_cursor(e)
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        self._stroke = None
        self.win.end_drag()
        self.win._end_resize()
        super().mouseReleaseEvent(e)

    def mouseDoubleClickEvent(self, e):
        if self.win.draw_mode == "none":
            item = self._hit_item(e.position().toPoint())
            if item is None or item is self.win.pixmap_item:
                self.win.add_text_item(self.mapToScene(e.position().toPoint()))
                return
        super().mouseDoubleClickEvent(e)

    def wheelEvent(self, e):
        # 有选中的文字标注 → 滚轮缩放文字本身
        if self.win.draw_mode == "none" and self.win.selected_text_items():
            f = 1.12 if e.angleDelta().y() > 0 else 1 / 1.12
            self.win.scale_selected_text(f)
            return
        if e.angleDelta().y() > 0:
            self.win.zoom(1.12)
        else:
            self.win.zoom(1 / 1.12)
