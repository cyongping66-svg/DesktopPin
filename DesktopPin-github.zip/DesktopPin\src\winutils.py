# -*- coding: utf-8 -*-
"""Win32 工具：鼠标穿透（click-through）、全局快捷键冲突探测、开机自启动"""
import ctypes
import os
import sys

GWL_EXSTYLE = -20
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020

user32 = ctypes.windll.user32

MOD_MAP = {"ctrl": 2, "alt": 1, "shift": 4, "win": 8}

SPECIAL_VK = {
    "space": 0x20, "enter": 0x0D, "tab": 0x09, "esc": 0x1B, "escape": 0x1B,
    "insert": 0x2D, "delete": 0x2E, "del": 0x2E, "home": 0x24, "end": 0x23,
    "pageup": 0x21, "pagedown": 0x22, "up": 0x26, "down": 0x28,
    "left": 0x25, "right": 0x27, "backspace": 0x08, "capslock": 0x14,
    "grave": 0xC0, "`": 0xC0,
}
for _i in range(1, 25):
    SPECIAL_VK[f"f{_i}"] = 0x6F + _i


def set_click_through(hwnd: int, enabled: bool) -> None:
    """开启后鼠标事件全部穿透该窗口（窗口仍然可见、置顶）。"""
    style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
    if enabled:
        style |= WS_EX_LAYERED | WS_EX_TRANSPARENT
    else:
        style &= ~WS_EX_TRANSPARENT
    user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)


HWND_TOPMOST = -1
SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE = 0x0001, 0x0002, 0x0010


def float_above(hwnd: int) -> None:
    """把窗口排到所有置顶窗口的最前面（不抢焦点、不改位置大小）。"""
    user32.SetWindowPos(ctypes.c_void_p(hwnd), ctypes.c_void_p(HWND_TOPMOST),
                        0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)


# 便签、贴图同属“底层置顶”，其余顶层窗口（提醒、对话框、设置岛……）一律压在它们上面
BASE_WINDOWS = {"MemoWindow", "UnlockBadge", "PinWindow", "PinToolbar", "CaptureOverlay"}


def install_popup_guard(app):
    """全局监听窗口显示/激活：弹窗出现时浮到最上层；便签被抬起时再把可见弹窗压回去。"""
    import weakref
    from PySide6.QtCore import QObject, QEvent, QTimer
    from PySide6.QtWidgets import QWidget
    import shiboken6

    popups = weakref.WeakSet()

    def _lift(w):
        if shiboken6.isValid(w) and w.isVisible():
            try:
                float_above(int(w.winId()))
            except Exception:
                pass

    def _lift_all():
        for w in list(popups):
            _lift(w)

    class _Guard(QObject):
        def eventFilter(self, obj, ev):
            t = ev.type()
            if t not in (QEvent.Show, QEvent.WindowActivate):
                return False
            if not isinstance(obj, QWidget) or not obj.isWindow():
                return False
            if type(obj).__name__ in BASE_WINDOWS:
                if popups:
                    QTimer.singleShot(30, _lift_all)
            elif t == QEvent.Show:
                popups.add(obj)
                for ms in (0, 150, 500, 1200):
                    QTimer.singleShot(ms, lambda w=obj: _lift(w))
            return False

    guard = _Guard(app)
    app.installEventFilter(guard)
    return guard


def _vk_of(token: str):
    token = token.strip().lower()
    if len(token) == 1:
        r = user32.VkKeyScanW(ord(token.upper()))
        if r != -1:
            return r & 0xFF
    return SPECIAL_VK.get(token)


def is_conflicted(hotkey: str) -> bool:
    """探测组合键是否已被其他软件注册（RegisterHotKey 失败=被占用）"""
    parts = [p.strip().lower() for p in hotkey.split("+") if p.strip()]
    if not parts:
        return False
    key = parts[-1]
    mods = 0
    for p in parts[:-1]:
        mods |= MOD_MAP.get(p, 0)
    vk = _vk_of(key)
    if vk is None:
        return False
    HOTKEY_ID = 0xBFFF
    ok = user32.RegisterHotKey(None, HOTKEY_ID, mods, vk)
    if ok:
        user32.UnregisterHotKey(None, HOTKEY_ID)
        return False
    return True


# ---------- 开机自启动（HKCU Run 键，无需管理员权限） ----------
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_NAME = "DesktopPin"


def autostart_target() -> str:
    """开机启动应执行的程序。打包后=主程序 exe；源码运行不支持。"""
    if getattr(sys, "frozen", False):
        return os.path.abspath(sys.executable)
    return ""


def set_autostart(enabled: bool) -> bool:
    """写入/删除注册表自启动项。返回是否成功。"""
    import winreg
    exe = autostart_target()
    if enabled and not exe:
        return False   # 源码环境不写注册表（会指向 python.exe，无意义）
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                            winreg.KEY_SET_VALUE) as k:
            if enabled:
                winreg.SetValueEx(k, RUN_NAME, 0, winreg.REG_SZ, f'"{exe}"')
            else:
                try:
                    winreg.DeleteValue(k, RUN_NAME)
                except FileNotFoundError:
                    pass
        return True
    except OSError:
        return False


def is_autostart_enabled() -> bool:
    """注册表里是否已经登记了本程序（以实际状态为准，不信配置）"""
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                            winreg.KEY_READ) as k:
            val, _ = winreg.QueryValueEx(k, RUN_NAME)
            return bool(val)
    except OSError:
        return False
