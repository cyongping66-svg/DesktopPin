# -*- coding: utf-8 -*-
"""DesktopPin 主程序：托盘 + 全局热键（可自定义）+ 便签 + 截图贴图 + 闹钟"""
import sys
import time
import traceback


def _install_crash_log():
    """v10：全局异常落盘 %APPDATA%/DesktopPin/error.log（排查卡死闪退）"""
    try:
        import config as _cfg
        import os
        os.makedirs(_cfg.DATA_DIR, exist_ok=True)
        log_path = os.path.join(_cfg.DATA_DIR, "error.log")
    except Exception:
        log_path = None

    def hook(exc_type, exc_value, tb):
        if log_path:
            try:
                with open(log_path, "a", encoding="utf-8") as f:
                    f.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n")
                    f.write("".join(traceback.format_exception(
                        exc_type, exc_value, tb)))
            except Exception:
                pass
        traceback.print_exception(exc_type, exc_value, tb)
        sys.__excepthook__(exc_type, exc_value, tb)

    sys.excepthook = hook


_install_crash_log()

# v13：降低递归深度上限。Qt→Python 回调相互嵌套时，每层消耗大量 C 栈，
# 默认 1000 层会在 C 栈(1MB)耗尽时触发 0xc00000fd 栈溢出硬崩溃；
# 降到 260 可在其发生前抛出可捕获的 RecursionError → 落盘日志而非闪退。
sys.setrecursionlimit(260)

from PySide6.QtCore import QObject, Signal, Qt, QTimer
from PySide6.QtGui import QIcon, QPixmap, QPainter, QColor, QPen, QBrush, QFont, QLinearGradient
from PySide6.QtWidgets import (
    QApplication, QSystemTrayIcon, QMenu, QMessageBox,
)

import config
import memo
from memo import MemoWindow
from capture import CaptureOverlay
from pin_window import PinWindow, apply_settings_to_pins
from island import SettingsIsland
from startup import StartupReminder, collect_past_memos
from alarm import AlarmManager

APP_INSTANCE = None

ACCENT = "#007AFF"


class HotkeyBridge(QObject):
    """keyboard 库回调在其他线程，用信号转回 Qt 主线程"""
    triggered = Signal(str)


class App:
    def __init__(self):
        global APP_INSTANCE
        APP_INSTANCE = self
        self.app = QApplication(sys.argv)
        self.app.setQuitOnLastWindowClosed(False)
        self.app.setApplicationName("DesktopPin")
        from winutils import install_popup_guard
        self._popup_guard = install_popup_guard(self.app)

        self.memos: list[MemoWindow] = []
        self._hk_handles = []
        self._island = None
        self.bridge = HotkeyBridge()
        self.bridge.triggered.connect(self._on_hotkey)

        # 注入设置入口（打开悬浮岛，带锚点便签）
        memo.open_island = self.open_island
        memo.open_memo = self.open_memo

        # 迁移旧数据 + 确保 backup 目录存在（用户要求目录随启动自动创建）
        config.migrate_legacy()
        try:
            config.backup_dir()
        except OSError:
            pass
        import os, glob
        ids = set()
        for f in glob.glob(os.path.join(config.memos_dir(), "memo_*.html")):
            ids.add(os.path.basename(f)[5:-5])
        for f in glob.glob(os.path.join(config.memos_dir(), "memo_*.txt")):
            ids.add(os.path.basename(f)[5:-4])
        past = sorted(ids)

        # v16：开机自启场景 —— 先开一张空白便签，再问是否打开过去的备忘
        cfg0 = config.load()
        self._reminder = None
        auto_on = False
        try:
            from winutils import is_autostart_enabled
            auto_on = is_autostart_enabled()
        except Exception:
            auto_on = bool(cfg0.get("autostart"))
        if auto_on and cfg0.get("startup_reminder", True) and past:
            self.new_memo()
            QTimer.singleShot(500, self._ask_open_past)
        else:
            for mid in past:
                self.memos.append(MemoWindow(mid))
            if not self.memos:
                self.new_memo()

        # 闹钟调度器
        self.alarms = AlarmManager()

        # 托盘
        self.tray = QSystemTrayIcon(self._make_icon())
        self.tray.setToolTip("DesktopPin — 便签 / 截图贴图 / 闹钟")
        menu = QMenu()
        menu.setStyleSheet(
            "QMenu{background:rgba(250,250,252,248);color:#1d1d1f;"
            "border:1px solid rgba(0,0,0,30);border-radius:12px;padding:5px;}"
            "QMenu::item{padding:6px 22px;border-radius:8px;font-size:12px;}"
            "QMenu::item:selected{background:#007AFF;color:white;}"
            "QMenu::separator{height:1px;background:rgba(0,0,0,28);margin:4px 10px;}"
        )
        cfg = config.load()
        a_set = menu.addAction("⚙ 设置")
        a_cap = menu.addAction(f"截图贴图 ({cfg['hotkeys']['shot']})")
        a_new = menu.addAction("新建便签")
        a_lock = menu.addAction(f"锁定/解锁便签 ({cfg['hotkeys']['lock']})")
        menu.addSeparator()
        a_help = menu.addAction("使用说明")
        a_quit = menu.addAction("退出")
        a_set.triggered.connect(lambda: self.open_island())
        a_cap.triggered.connect(self.screenshot)
        a_new.triggered.connect(self.new_memo)
        a_lock.triggered.connect(self.toggle_all_memos)
        a_help.triggered.connect(self.show_help)
        a_quit.triggered.connect(self.quit)
        self.tray.setContextMenu(menu)
        self.tray.show()
        # 左键托盘 = 打开设置岛；右键 = 菜单（Qt 默认）
        self.tray.activated.connect(self._on_tray)

        self._overlay = None
        self._register_hotkeys()

    # ---------- 托盘交互 ----------
    def _on_tray(self, reason):
        if reason == QSystemTrayIcon.Trigger:      # 单击
            self.open_island()
        elif reason == QSystemTrayIcon.MiddleClick:
            self.screenshot()

    # ---------- 全局热键 ----------
    def _register_hotkeys(self) -> bool:
        import keyboard
        for h in self._hk_handles:
            try:
                keyboard.remove_hotkey(h)
            except Exception:
                pass
        self._hk_handles = []
        cfg = config.load()
        all_ok = True
        for action, hk in cfg["hotkeys"].items():
            if not hk:
                continue
            try:
                self._hk_handles.append(keyboard.add_hotkey(
                    hk, lambda a=action: self.bridge.triggered.emit(a)))
            except Exception:
                all_ok = False
        return all_ok

    # ---------- 设置岛 ----------
    def open_island(self, anchor=None):
        if self._island is None:
            self._island = SettingsIsland(
                on_applied=self._settings_applied, alarm_manager=self.alarms)
        self._island.refresh()
        self._island.place(anchor)
        self._island.show()
        self._island.raise_()
        self._island.activateWindow()

    def _settings_applied(self, cfg) -> bool:
        memo.apply_settings_to_all()
        apply_settings_to_pins()
        return self._register_hotkeys()

    # ---------- 动作 ----------
    def _on_hotkey(self, key: str):
        if key == "shot":
            self.screenshot()
        elif key == "lock":
            self.toggle_all_memos()
        elif key == "new":
            self.new_memo()
        elif key == "quit":
            self.quit()

    def screenshot(self):
        if self._overlay is not None:
            return
        self._overlay = CaptureOverlay(on_done=self._on_captured)

    def _on_captured(self, pixmap):
        self._overlay = None
        if pixmap and not pixmap.isNull():
            PinWindow(pixmap)

    def new_memo(self):
        m = MemoWindow(str(int(time.time())))
        self.memos.append(m)

    def open_memo(self, memo_id):
        m = MemoWindow(memo_id)
        self.memos.append(m)

    # ---------- v16：启动提醒 ----------
    def _ask_open_past(self):
        items = collect_past_memos()
        if not items:
            return
        self._reminder = StartupReminder(items, on_open=self._open_past)
        self._reminder.show()
        self._reminder.raise_()
        self._reminder.activateWindow()

    def _open_past(self, ids):
        opened = {m.memo_id for m in self.memos}
        for mid in ids:
            if mid in opened:
                continue
            self.open_memo(mid)

    def toggle_all_memos(self):
        # 优先锁定/解锁鼠标所在的便签；不在任何便签上 → 全部切换
        m = memo.memo_under_cursor()
        if m is not None:
            m.toggle_lock()
            return
        for m in self.memos:
            if m.isVisible():
                m.toggle_lock()

    def show_help(self):
        cfg = config.load()
        hk = cfg["hotkeys"]
        QMessageBox.information(None, "DesktopPin 使用说明",
            f"{hk['shot']} —— 截图（鼠标所在屏，选区可拖拽/手柄调整）\n"
            f"{hk['lock']} —— 锁定/解锁便签（优先鼠标所在便签）\n\n"
            "托盘：左键打开设置岛 · 右键展开菜单 · 中键快速截图\n\n"
            "便签：☰ 设置岛 · 右下角手柄自由调整大小\n"
            "　　　工具栏：字号/加粗/颜色/高亮/分点 · 锁定后点右上角 🔓\n"
            "贴图：编辑栏（📷OCR·画笔·彩点·粗细·橡皮·文字·清空）紧贴图片上方\n"
            "　　　图片四边四角可直接拖拽拉伸 · 滚轮缩放 · 右键 OCR/复制（含笔迹）\n"
            "　　　文字：点「文字」后在图片任意位置单击落点，可编辑/拖拽/A±调字号\n"
            "　　　　　　选中文字后滚轮放大缩小 · Esc 退出当前模式\n"
            "闹钟：设置岛新建（弹窗+铃声+延时提醒，默认 3 分钟）\n"
            "AI：设置岛配置接口后一键总结全部便签")

    def quit(self):
        self.alarms.stop_all()
        for m in self.memos:
            m._archive_on_close = False  # 程序退出不归档
            m.close()
        self.app.quit()

    @staticmethod
    def _make_icon() -> QIcon:
        """图钉风格托盘图标"""
        pm = QPixmap(64, 64)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        # 圆角蓝底
        grad = QLinearGradient(0, 0, 0, 64)
        grad.setColorAt(0, QColor("#3395ff"))
        grad.setColorAt(1, QColor(ACCENT))
        p.setBrush(QBrush(grad))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(4, 4, 56, 56, 16, 16)
        # 白色图钉（圆头 + 针）
        p.setBrush(QColor("white"))
        p.setPen(QPen(QColor("white"), 5, Qt.SolidLine, Qt.RoundCap))
        p.drawEllipse(24, 18, 16, 16)
        p.drawLine(32, 34, 32, 50)
        p.end()
        return QIcon(pm)

    def run(self):
        sys.exit(self.app.exec())


if __name__ == "__main__":
    App().run()
