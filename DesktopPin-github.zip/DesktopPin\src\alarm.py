# -*- coding: utf-8 -*-
"""桌面闹钟：定时提醒（弹窗+铃声循环）、延时提醒（自定义分钟数，默认 3 分钟）"""
import math
import os
import time
import wave

import numpy as np
from PySide6.QtCore import Qt, QObject, QTimer, QDateTime, QTime, QUrl
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QDialog, QTimeEdit, QLineEdit, QCheckBox, QSpinBox, QComboBox,
    QApplication, QSizePolicy,
)

import config

ACCENT = "#007AFF"

RINGTONES = {
    "柔和": ("soft.wav", [523, 659, 784], 0.30, 0.15),
    "默认": ("default.wav", [880, 880, 880], 0.18, 0.12),
    "急促": ("urgent.wav", [1200, 1200, 1200, 1200], 0.09, 0.05),
}

_sound_ok = True
try:
    from PySide6.QtMultimedia import QSoundEffect
except ImportError:
    _sound_ok = False


def _write_wav(path, freqs, dur, gap, rate=44100):
    frames = []
    for f in freqs:
        t = np.linspace(0, dur, int(rate * dur), False)
        tone = 0.6 * np.sin(2 * math.pi * f * t) * np.exp(-t * 6)
        frames.append((tone * 32767).astype(np.int16))
        frames.append(np.zeros(int(rate * gap), dtype=np.int16))
    data = np.concatenate(frames)
    with wave.open(path, "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(data.tobytes())


def ringtone_path(name: str) -> str:
    d = os.path.join(config.DATA_DIR, "ringtones")
    os.makedirs(d, exist_ok=True)
    fname, freqs, dur, gap = RINGTONES.get(name, RINGTONES["默认"])
    p = os.path.join(d, fname)
    if not os.path.exists(p):
        _write_wav(p, freqs, dur, gap)
    return p


def next_occurrence(hhmm: str, daily: bool) -> str:
    """下一次触发时间（ISO）。daily=每天；否则仅最近一次（今天已过则明天）"""
    now = QDateTime.currentDateTime()
    t = QTime.fromString(hhmm, "hh:mm")
    nxt = QDateTime(now.date(), t)
    if nxt <= now:
        nxt = nxt.addDays(1)
        if not daily:
            pass  # 单次闹钟：过了今天则明天（触发后自动停用）
    return nxt.toString(Qt.ISODate)


class AlarmDialog(QDialog):
    """新建/编辑闹钟"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("新建闹钟")
        self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        self.setStyleSheet(f"""
            QDialog {{ background: rgba(250,250,252,252); }}
            QLabel {{ color: #1d1d1f; font-size: 13px; }}
            QTimeEdit, QLineEdit, QSpinBox, QComboBox {{
                background: white; color: #1d1d1f;
                border: 1px solid rgba(0,0,0,22); border-radius: 8px;
                padding: 5px 8px; font-size: 13px;
            }}
            QCheckBox {{ color: #3a3a3c; font-size: 12px; }}
            QPushButton {{ background: {ACCENT}; color: white; border: none;
                border-radius: 12px; padding: 7px 18px; font-size: 12px; }}
        """)

        v = QVBoxLayout(self)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(9)

        row1 = QHBoxLayout()
        row1.addWidget(QLabel("时间"))
        self.time = QTimeEdit()
        self.time.setDisplayFormat("HH:mm")
        now = QTime.currentTime().addSecs(3600)
        self.time.setTime(now)
        row1.addWidget(self.time)
        row1.addWidget(QLabel("标签"))
        self.label = QLineEdit()
        self.label.setPlaceholderText("如：日报提交")
        row1.addWidget(self.label)
        v.addLayout(row1)

        row2 = QHBoxLayout()
        self.daily = QCheckBox("每天重复")
        row2.addWidget(self.daily)
        row2.addWidget(QLabel("延时提醒"))
        self.snooze = QSpinBox()
        self.snooze.setRange(1, 60)
        self.snooze.setValue(3)
        self.snooze.setSuffix(" 分钟")
        row2.addWidget(self.snooze)
        v.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("铃声"))
        self.ringtone = QComboBox()
        self.ringtone.addItems(RINGTONES.keys())
        row3.addWidget(self.ringtone)
        self.sound = QCheckBox("响铃")
        self.sound.setChecked(True)
        row3.addWidget(self.sound)
        v.addLayout(row3)

        btns = QHBoxLayout()
        btns.addStretch()
        btn_ok = QPushButton("添加闹钟")
        btn_cancel = QPushButton("取消")
        btn_cancel.setStyleSheet(
            "background:rgba(0,0,0,22);color:#1d1d1f;")
        btns.addWidget(btn_ok)
        btns.addWidget(btn_cancel)
        v.addLayout(btns)
        btn_ok.clicked.connect(self.accept)
        btn_cancel.clicked.connect(self.reject)

    def alarm(self) -> dict:
        hhmm = self.time.time().toString("hh:mm")
        return {
            "id": str(time.time_ns()),
            "time": hhmm,
            "label": self.label.text().strip() or "提醒",
            "daily": self.daily.isChecked(),
            "snooze": self.snooze.value(),
            "ringtone": self.ringtone.currentText(),
            "sound": self.sound.isChecked(),
            "active": True,
            "next": next_occurrence(hhmm, self.daily.isChecked()),
        }


class AlarmPopup(QWidget):
    """到点弹窗：大时间 + 标签 + 停止/延时按钮，铃声循环直到处理"""

    def __init__(self, alarm: dict, on_stop, on_snooze):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.on_stop = on_stop
        self.on_snooze = on_snooze
        self.alarm = alarm

        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet(f"""
            QFrame#card {{ background: rgba(250,250,252,252);
                border-radius: 22px; border: 1px solid rgba(0,0,0,26); }}
            QLabel {{ background: transparent; }}
            QLabel#time {{ color: #1d1d1f; font-size: 42px; font-weight: 700; }}
            QLabel#label {{ color: #86868b; font-size: 15px; }}
            QLabel#title {{ color: {ACCENT}; font-size: 11px; font-weight: 600; }}
            QPushButton {{ border: none; border-radius: 14px; padding: 9px 20px;
                font-size: 13px; }}
            QPushButton#stop {{ background: {ACCENT}; color: white; font-weight: 600; }}
            QPushButton#stop:hover {{ background: #3395ff; }}
            QPushButton#snooze {{ background: rgba(0,0,0,20); color: #1d1d1f; }}
            QPushButton#snooze:hover {{ background: rgba(0,0,0,44); }}
        """)

        card = QFrame(objectName="card")
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(card)
        v = QVBoxLayout(card)
        v.setContentsMargins(28, 20, 28, 22)
        v.setSpacing(6)

        title = QLabel("⏰  闹钟提醒")
        title.setObjectName("title")
        v.addWidget(title, 0, Qt.AlignHCenter)
        self.lbl_time = QLabel(alarm["time"])
        self.lbl_time.setObjectName("time")
        v.addWidget(self.lbl_time, 0, Qt.AlignHCenter)
        self.lbl_label = QLabel(alarm.get("label", ""))
        self.lbl_label.setObjectName("label")
        v.addWidget(self.lbl_label, 0, Qt.AlignHCenter)

        v.addSpacing(8)
        btns = QHBoxLayout()
        self.btn_snooze = QPushButton(f"💤 延时 {alarm.get('snooze', 3)} 分钟")
        self.btn_snooze.setObjectName("snooze")
        self.btn_stop = QPushButton("知道了")
        self.btn_stop.setObjectName("stop")
        btns.addWidget(self.btn_snooze, 1)
        btns.addWidget(self.btn_stop, 1)
        v.addLayout(btns)

        self.btn_stop.clicked.connect(self._stop)
        self.btn_snooze.clicked.connect(self._snooze)

        # 时钟跳动
        self._tick = QTimer(self)
        self._tick.timeout.connect(
            lambda: self.lbl_time.setText(
                QDateTime.currentDateTime().time().toString("HH:mm:ss")))
        self._tick.start(1000)

        # 铃声循环
        self._player = None
        if _sound_ok and alarm.get("sound", True):
            from PySide6.QtMultimedia import QSoundEffect
            self._player = QSoundEffect()
            self._player.setSource(QUrl.fromLocalFile(
                ringtone_path(alarm.get("ringtone", "默认"))))
            self._player.setLoopCount(QSoundEffect.Loop.Infinite)
            self._player.setVolume(0.7)
            self._player.play()

        self.adjustSize()
        g = QApplication.primaryScreen().availableGeometry()
        self.move(g.center().x() - self.width() // 2,
                  g.center().y() - self.height() // 2)
        self.show()
        self.activateWindow()
        self.raise_()

    def _stop(self):
        self._done(self.on_stop)

    def _snooze(self):
        self._done(self.on_snooze)

    def _done(self, cb):
        if self._player:
            self._player.stop()
        self._tick.stop()
        self.close()
        cb(self.alarm)


class AlarmManager(QObject):
    """闹钟调度器：15 秒轮询，到点弹 AlarmPopup"""

    def __init__(self):
        super().__init__()
        self._popups = []
        self.timer = QTimer(self)
        self.timer.setInterval(15000)
        self.timer.timeout.connect(self._check)
        self.timer.start()

    # ---------- 配置读写 ----------
    @staticmethod
    def _alarms() -> list:
        return config.load().get("alarms", [])

    @staticmethod
    def _save_alarms(alarms):
        cfg = config.load()
        cfg["alarms"] = alarms
        config.save(cfg)

    # ---------- CRUD ----------
    def add(self, alarm: dict):
        alarms = self._alarms()
        alarms.append(alarm)
        self._save_alarms(alarms)

    def remove(self, alarm_id: str):
        self._save_alarms([a for a in self._alarms() if a["id"] != alarm_id])

    def toggle(self, alarm_id: str):
        alarms = self._alarms()
        for a in alarms:
            if a["id"] == alarm_id:
                a["active"] = not a.get("active", True)
                if a["active"]:
                    a["next"] = next_occurrence(a["time"], a.get("daily", False))
        self._save_alarms(alarms)

    # ---------- 触发 ----------
    def _check(self):
        now = QDateTime.currentDateTime()
        alarms = self._alarms()
        changed = False
        for a in alarms:
            if not a.get("active", True):
                continue
            nxt = QDateTime.fromString(a.get("next", ""), Qt.ISODate)
            if not nxt.isValid():
                a["next"] = next_occurrence(a["time"], a.get("daily", False))
                changed = True
                continue
            if now >= nxt:
                # 触发（弹窗接管后续状态）
                popup = AlarmPopup(a, self._on_stop, self._on_snooze)
                self._popups.append(popup)
                # 先置为待处理：60 秒内不重复弹
                a["next"] = now.addSecs(60 * 60 * 24).toString(Qt.ISODate)
                a["active"] = False  # 由弹窗回调决定恢复
                changed = True
        if changed:
            self._save_alarms(alarms)

    def _on_stop(self, alarm):
        alarms = self._alarms()
        for a in alarms:
            if a["id"] == alarm["id"]:
                if a.get("daily", False):
                    a["active"] = True
                    a["next"] = next_occurrence(a["time"], True)
                # 单次闹钟：保持停用
        self._save_alarms(alarms)
        self._drop(alarm)

    def _on_snooze(self, alarm):
        snooze_min = alarm.get("snooze", 3)
        alarms = self._alarms()
        for a in alarms:
            if a["id"] == alarm["id"]:
                a["active"] = True
                a["next"] = QDateTime.currentDateTime().addSecs(
                    snooze_min * 60).toString(Qt.ISODate)
        self._save_alarms(alarms)
        self._drop(alarm)

    def _drop(self, alarm):
        from toast import show_toast
        show_toast(f"闹钟已处理：{alarm.get('label', '')}")
        self._popups = [p for p in self._popups
                        if p.isVisible() and p.alarm["id"] != alarm["id"]]

    def stop_all(self):
        self.timer.stop()
        for p in self._popups:
            try:
                p.close()
            except RuntimeError:
                pass
