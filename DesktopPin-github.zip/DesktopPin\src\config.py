# -*- coding: utf-8 -*-
"""全局配置：主题 / 透明度 / 快捷键 / 同步目录（settings.json 存本地）
数据目录支持切换：默认 %APPDATA%/DesktopPin，可选网盘同步目录（多设备共享便签）
"""
import json
import os
import sys

DATA_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "DesktopPin")
CONF_PATH = os.path.join(DATA_DIR, "settings.json")

DEFAULT = {
    "theme": "dark",        # dark / light
    "opacity": 100,          # 50-100 窗口不透明度
    "hotkeys": {
        "shot": "ctrl+alt+s",
        "lock": "ctrl+alt+d",
    },
    "share": {"shot": False, "lock": False},
    "sync_dir": "",          # 多设备同步目录（网盘同步盘路径，空=仅本机）
    "alarms": [],            # 桌面闹钟列表
    "ai": {                  # AI 接入（OpenAI 兼容接口）
        "base_url": "https://api.deepseek.com/v1",
        "api_key": "",
        "model": "deepseek-chat",
    },
    "backup_dir": "",        # 便签本地备份目录（首次保存时定下，可在设置岛手动更改）
    "save_to": {"local": True, "feishu": True},   # 点「保存」时执行哪几种方式
    "autostart": False,      # 开机自启动
    "startup_reminder": True,  # 启动时提醒打开过去的备忘
    "feishu": {              # 保存时写入的飞书新版文档
        "app_id": "",
        "app_secret": "",
        "doc_url": "",
        "document_id": "",
        "doc_url_resolved": "",
    },
}

ACTION_NAMES = {
    "shot": "截图贴图",
    "lock": "锁定/解锁便签",
}


def load() -> dict:
    cfg = json.loads(json.dumps(DEFAULT))  # deep copy
    try:
        with open(CONF_PATH, encoding="utf-8") as f:
            data = json.load(f)
        for k in cfg:
            if k in data:
                if isinstance(cfg[k], dict) and isinstance(data[k], dict):
                    cfg[k].update(data[k])
                else:
                    cfg[k] = data[k]
    except Exception:
        pass
    # v9：剔除「新建便签 / 退出程序」快捷键，清理旧配置残留
    for legacy in ("new", "quit"):
        cfg["hotkeys"].pop(legacy, None)
        cfg["share"].pop(legacy, None)
    return cfg


def save(cfg: dict) -> None:
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CONF_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


# ---------- 数据目录（跟随同步目录） ----------
def data_root() -> str:
    sd = load().get("sync_dir") or ""
    if sd and os.path.isdir(sd):
        return sd
    return DATA_DIR


def memos_dir() -> str:
    d = os.path.join(data_root(), "memos")
    os.makedirs(d, exist_ok=True)
    return d


def history_dir() -> str:
    d = os.path.join(data_root(), "history")
    os.makedirs(d, exist_ok=True)
    return d


def imgs_dir() -> str:
    d = os.path.join(data_root(), "imgs")
    os.makedirs(d, exist_ok=True)
    return d


def memo_file(memo_id: str, ext: str = "html", archived: bool = False) -> str:
    d = history_dir() if archived else memos_dir()
    return os.path.join(d, f"memo_{memo_id}.{ext}")


# ---------- 项目目录 / 本地备份 ----------
def project_dir() -> str:
    """程序所在「项目目录」——backup 等导出物的根。
    打包运行: <项目>\\app\\DesktopPin\\DesktopPin.exe → <项目>
    源码运行: <项目>\\src\\*.py 或 <项目>\\*.py → <项目>
    """
    if getattr(sys, "frozen", False):
        here = os.path.dirname(os.path.abspath(sys.executable))
        p = here
        for _ in range(4):
            if (os.path.isdir(os.path.join(p, "app"))
                    or os.path.isfile(os.path.join(p, "DesktopPin启动器.exe"))):
                return p
            up = os.path.dirname(p)
            if up == p:
                break
            p = up
        return here
    here = os.path.dirname(os.path.abspath(__file__))
    if os.path.basename(here).lower() in ("src", "app"):
        return os.path.dirname(here)
    return here


def backup_dir() -> str:
    """便签「保存到本地」的落点。首次调用时确定为 <项目>\\backup 并写回配置，
    之后程序不会自动改动；只有用户在设置岛「更改位置」时才会变。"""
    cfg = load()
    d = (cfg.get("backup_dir") or "").strip()
    if not d:
        d = os.path.join(project_dir(), "backup")
        cfg["backup_dir"] = d
        try:
            save(cfg)
        except OSError:
            pass
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d


def migrate_legacy():
    """旧版 %APPDATA%/DesktopPin/memo_*.html|txt 迁移到 memos/"""
    import glob
    import shutil
    legacy = glob.glob(os.path.join(DATA_DIR, "memo_*.html")) + \
        glob.glob(os.path.join(DATA_DIR, "memo_*.txt"))
    if not legacy:
        return
    for f in legacy:
        base = os.path.basename(f)
        dst = os.path.join(memos_dir(), base)
        if not os.path.exists(dst):
            try:
                shutil_move(f, dst)
            except OSError:
                pass


def shutil_move(src, dst):
    import shutil
    shutil.move(src, dst)
