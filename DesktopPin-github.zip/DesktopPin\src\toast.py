# -*- coding: utf-8 -*-
"""Toast 轻提示（SwiftUI 风格）：屏幕底部居中浮出，自动淡出"""
from PySide6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout

ACCENT = "#007AFF"
DANGER = "#ff3b30"

_active = None   # 持有当前 Toast 的引用：无父窗口若不被引用，show_toast 一返回
                 # 就会被 Python GC 回收 → 提醒从未真正显示过（v16.2 修复）


def show_toast(text: str, ok: bool = True):
    """全局函数：主线程调用"""
    global _active
    if _active is not None:
        try:
            _active.close()
            _active.deleteLater()
        except RuntimeError:
            pass          # 旧 toast 已被 Qt 删除，忽略
    _active = Toast(text, ok)


class Toast(QWidget):
    def __init__(self, text: str, ok: bool = True):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_ShowWithoutActivating)

        accent = ACCENT if ok else DANGER
        icon = "✓" if ok else "✕"
        label = QLabel(f"{icon}  {text}")
        label.setStyleSheet(f"""
            QLabel {{
                background: rgba(28,28,30,242); color: #f5f5f7;
                border-radius: 18px; padding: 11px 22px; font-size: 13px;
            }}
        """)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(label)
        self.adjustSize()

        # 屏幕底部居中（iPhone 弹出位置）
        screen = self.screen() or QWidget().screen()
        g = screen.availableGeometry()
        self.move(g.center().x() - self.width() // 2,
                  g.bottom() - self.height() - 64)

        self.setWindowOpacity(0.98)
        self.show()

        QTimer.singleShot(1800, self._fade)

    def _fade(self):
        anim = QPropertyAnimation(self, b"windowOpacity", self)
        anim.setDuration(450)
        anim.setStartValue(0.98)
        anim.setEndValue(0.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.finished.connect(self.close)
        anim.start()
        self._anim = anim
