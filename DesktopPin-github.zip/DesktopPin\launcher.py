# -*- coding: utf-8 -*-
"""DesktopPin 启动器：启动同目录 app\DesktopPin\DesktopPin.exe"""
import os
import sys
import subprocess

base = os.path.dirname(sys.executable)
for exe in (os.path.join(base, "app", "DesktopPin", "DesktopPin.exe"),
            os.path.join(base, "app", "DesktopPin.exe")):
    if os.path.exists(exe):
        subprocess.Popen([exe], cwd=os.path.dirname(exe))
        break
else:
    import ctypes
    ctypes.windll.user32.MessageBoxW(
        0, "未找到主程序 app\\DesktopPin\\DesktopPin.exe", "DesktopPin 启动器", 0x10)
